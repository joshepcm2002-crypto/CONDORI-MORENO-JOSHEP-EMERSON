package Modelo;

/** Un nodo almacena un Alumno y la referencia al nodo siguiente. */
public class CNodo {
    private Alumno alumno;
    private CNodo siguiente;

    public CNodo(Alumno alumno) {
        this.alumno = alumno;
        this.siguiente = null;
    }

    public Alumno getAlumno() { return alumno; }
    public void setAlumno(Alumno alumno) { this.alumno = alumno; }
    public CNodo getSiguiente() { return siguiente; }
    public void setSiguiente(CNodo siguiente) { this.siguiente = siguiente; }
}
