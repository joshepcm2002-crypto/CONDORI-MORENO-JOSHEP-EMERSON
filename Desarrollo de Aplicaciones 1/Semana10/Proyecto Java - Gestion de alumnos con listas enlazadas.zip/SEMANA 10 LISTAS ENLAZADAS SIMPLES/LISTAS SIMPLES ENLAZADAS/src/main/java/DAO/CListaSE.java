package DAO;

import Modelo.Alumno;
import Modelo.CNodo;

/**
 * Lista simplemente enlazada. inicio -> nodo -> nodo -> null.
 * No usa ArrayList ni arreglos para guardar alumnos.
 * Las inserciones y eliminaciones cambian referencias de nodos.
 */
public class CListaSE {
    private CNodo inicio;
    private int cantidad;

    public CListaSE() {
        inicio = null;
        cantidad = 0;
    }

    // EJERCICIO 1a: insertar al inicio.
    public void insertarInicio(Alumno alumno) {
        validarAlumnoNuevo(alumno);
        CNodo nuevo = new CNodo(alumno);
        nuevo.setSiguiente(inicio);
        inicio = nuevo;
        cantidad++;
    }

    // EJERCICIO 1b: insertar al final.
    public void insertarFinal(Alumno alumno) {
        validarAlumnoNuevo(alumno);
        CNodo nuevo = new CNodo(alumno);
        if (estaVacia()) {
            inicio = nuevo;
        } else {
            CNodo actual = inicio;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevo);
        }
        cantidad++;
    }

    // EJERCICIO 1c: insertar en posicion x (posiciones desde 1).
    public void insertarEnPosicion(Alumno alumno, int posicion) {
        if (posicion < 1 || posicion > cantidad + 1) {
            throw new IllegalArgumentException("Posicion valida: 1 a " + (cantidad + 1));
        }
        if (posicion == 1) {
            insertarInicio(alumno);
            return;
        }
        validarAlumnoNuevo(alumno);
        CNodo anterior = inicio;
        for (int i = 1; i < posicion - 1; i++) {
            anterior = anterior.getSiguiente();
        }
        CNodo nuevo = new CNodo(alumno);
        nuevo.setSiguiente(anterior.getSiguiente());
        anterior.setSiguiente(nuevo);
        cantidad++;
    }

    // EJERCICIO 1d: insertar DESPUES de un objeto Alumno de referencia.
    public void insertarPorReferencia(Alumno referencia, Alumno alumno) {
        if (referencia == null) {
            throw new IllegalArgumentException("No existe el alumno de referencia.");
        }
        validarAlumnoNuevo(alumno);
        CNodo actual = inicio;
        while (actual != null && actual.getAlumno() != referencia) {
            actual = actual.getSiguiente();
        }
        if (actual == null) {
            throw new IllegalArgumentException("La referencia no pertenece a la lista.");
        }
        CNodo nuevo = new CNodo(alumno);
        nuevo.setSiguiente(actual.getSiguiente());
        actual.setSiguiente(nuevo);
        cantidad++;
    }

    // EJERCICIO 2a: eliminar el primer nodo.
    public Alumno eliminarInicio() {
        if (estaVacia()) return null;
        Alumno eliminado = inicio.getAlumno();
        inicio = inicio.getSiguiente();
        cantidad--;
        return eliminado;
    }

    // EJERCICIO 2b: eliminar el ultimo nodo.
    public Alumno eliminarFinal() {
        if (estaVacia()) return null;
        if (inicio.getSiguiente() == null) return eliminarInicio();
        CNodo anterior = inicio;
        while (anterior.getSiguiente().getSiguiente() != null) {
            anterior = anterior.getSiguiente();
        }
        Alumno eliminado = anterior.getSiguiente().getAlumno();
        anterior.setSiguiente(null);
        cantidad--;
        return eliminado;
    }

    // EJERCICIO 2c: eliminar en posicion x (posiciones desde 1).
    public Alumno eliminarEnPosicion(int posicion) {
        if (estaVacia()) return null;
        if (posicion < 1 || posicion > cantidad) {
            throw new IllegalArgumentException("Posicion valida: 1 a " + cantidad);
        }
        if (posicion == 1) return eliminarInicio();
        CNodo anterior = inicio;
        for (int i = 1; i < posicion - 1; i++) {
            anterior = anterior.getSiguiente();
        }
        CNodo eliminado = anterior.getSiguiente();
        anterior.setSiguiente(eliminado.getSiguiente());
        cantidad--;
        return eliminado.getAlumno();
    }

    // EJERCICIO 2d: eliminar el nodo que contiene la MISMA referencia Alumno.
    // En el menu, primero se busca el Alumno por su codigo.
    public Alumno eliminarPorReferencia(Alumno referencia) {
        if (estaVacia() || referencia == null) return null;
        if (inicio.getAlumno() == referencia) return eliminarInicio();
        CNodo anterior = inicio;
        while (anterior.getSiguiente() != null) {
            if (anterior.getSiguiente().getAlumno() == referencia) {
                CNodo eliminado = anterior.getSiguiente();
                anterior.setSiguiente(eliminado.getSiguiente());
                cantidad--;
                return eliminado.getAlumno();
            }
            anterior = anterior.getSiguiente();
        }
        return null;
    }

    // EJERCICIO 3: buscar alumno por codigo.
    public Alumno buscarPorCodigo(String codigo) {
        if (codigo == null) return null;
        CNodo actual = inicio;
        while (actual != null) {
            if (actual.getAlumno().getCodigo().equalsIgnoreCase(codigo.trim())) {
                return actual.getAlumno();
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    // EJERCICIO 4: recorrer sin eliminar ni cambiar enlaces.
    public String mostrarTodos() {
        if (estaVacia()) return "No hay alumnos registrados.";
        StringBuilder texto = new StringBuilder();
        CNodo actual = inicio;
        int posicion = 1;
        while (actual != null) {
            texto.append(posicion).append(". ").append(actual.getAlumno())
                    .append(System.lineSeparator());
            actual = actual.getSiguiente();
            posicion++;
        }
        return texto.toString();
    }

    // EJERCICIO 5: UN metodo que permite ordenar por codigo (ascendente)
    // o por promedio (descendente). Intercambia datos, NO enlaces.
    public void ordenar(boolean porPromedio) {
        for (int i = 0; i < cantidad - 1; i++) {
            CNodo actual = inicio;
            while (actual.getSiguiente() != null) {
                Alumno a = actual.getAlumno();
                Alumno b = actual.getSiguiente().getAlumno();
                boolean cambiar = porPromedio
                        ? a.getPromedio() < b.getPromedio()
                        : a.getCodigo().compareToIgnoreCase(b.getCodigo()) > 0;
                if (cambiar) {
                    actual.setAlumno(b);
                    actual.getSiguiente().setAlumno(a);
                }
                actual = actual.getSiguiente();
            }
        }
    }

    // EJERCICIO 6: intercambiar alumnos identificados por sus codigos.
    public boolean intercambiar(String codigo1, String codigo2) {
        CNodo primero = buscarNodo(codigo1);
        CNodo segundo = buscarNodo(codigo2);
        if (primero == null || segundo == null) return false;
        Alumno temporal = primero.getAlumno();
        primero.setAlumno(segundo.getAlumno());
        segundo.setAlumno(temporal);
        return true;
    }

    // EJERCICIO 7: numero de alumnos almacenados.
    public int obtenerTamanio() {
        return cantidad;
    }

    // EJERCICIO 8: modificar atributos sin cambiar el codigo identificador.
    public boolean modificar(String codigo, String nombre, int edad, double promedio) {
        Alumno alumno = buscarPorCodigo(codigo);
        if (alumno == null) return false;
        // Validar todos los datos ANTES de modificar algun atributo.
        Alumno datosValidos = new Alumno(alumno.getCodigo(), nombre, edad, promedio);
        alumno.setNombre(datosValidos.getNombre());
        alumno.setEdad(datosValidos.getEdad());
        alumno.setPromedio(datosValidos.getPromedio());
        return true;
    }

    // Validacion adicional mostrada en el menu del ingeniero.
    public boolean estaVacia() {
        return inicio == null;
    }

    private CNodo buscarNodo(String codigo) {
        if (codigo == null) return null;
        CNodo actual = inicio;
        while (actual != null) {
            if (actual.getAlumno().getCodigo().equalsIgnoreCase(codigo.trim())) {
                return actual;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    private void validarAlumnoNuevo(Alumno alumno) {
        if (alumno == null) {
            throw new IllegalArgumentException("El alumno no puede ser null.");
        }
        if (buscarPorCodigo(alumno.getCodigo()) != null) {
            throw new IllegalArgumentException("Ya existe un alumno con ese codigo.");
        }
    }
}
