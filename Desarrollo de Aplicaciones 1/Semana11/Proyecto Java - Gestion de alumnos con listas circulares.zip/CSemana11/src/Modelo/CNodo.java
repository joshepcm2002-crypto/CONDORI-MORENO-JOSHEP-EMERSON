package Modelo;

/**
 * Nodo de la lista circular simplemente enlazada.
 * dato = el alumno; sig = enlace al siguiente nodo.
 * En una lista circular el sig del ultimo nodo NO es null: apunta al primero.
 */
public class CNodo {

    private Alumno dato;
    private CNodo sig;

    public CNodo(Alumno dato) {
        this.dato = dato;
        this.sig = null;
    }

    public Alumno getDato() {
        return dato;
    }

    public void setDato(Alumno dato) {
        this.dato = dato;
    }

    public CNodo getSig() {
        return sig;
    }

    public void setSig(CNodo sig) {
        this.sig = sig;
    }
}
