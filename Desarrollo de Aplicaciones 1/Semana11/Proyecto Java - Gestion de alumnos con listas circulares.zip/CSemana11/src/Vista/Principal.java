package Vista;

/**
 * SEMANA 11 - LISTAS CIRCULARES SIMPLEMENTE ENLAZADAS
 * Proyecto 01: Sistema de gestion de alumnos.
 */
public class Principal {

    public static void main(String[] args) {
        MenuOpciones sistema = new MenuOpciones();
        sistema.menu();
    }
}
