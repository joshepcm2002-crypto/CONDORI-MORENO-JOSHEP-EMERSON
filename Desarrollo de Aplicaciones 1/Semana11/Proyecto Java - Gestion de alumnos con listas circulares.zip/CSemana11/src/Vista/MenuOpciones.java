package Vista;

import DAO.CListaCircular;
import Modelo.Alumno;
import java.util.Scanner;

/**
 * Menu del sistema de gestion de alumnos con una lista circular simplemente enlazada.
 * Lee y valida los datos por teclado y llama a los metodos de CListaCircular.
 */
public class MenuOpciones {

    private final Scanner teclado = new Scanner(System.in);
    private final CListaCircular lista = new CListaCircular();

    // Menu principal
    public void menu() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opcion: ");
            switch (opcion) {
                case 1: lista.insertarInicio(leerAlumnoNuevo()); ok("Alumno insertado al inicio."); break;
                case 2: lista.insertarFinal(leerAlumnoNuevo()); ok("Alumno insertado al final."); break;
                case 3: insertarEnPosicion(); break;
                case 4: insertarPorReferencia(); break;
                case 5: informarEliminado(lista.eliminarInicio()); break;
                case 6: informarEliminado(lista.eliminarFinal()); break;
                case 7: eliminarEnPosicion(); break;
                case 8: informarEliminado(lista.eliminarReferencia(leerTexto("Codigo del alumno a eliminar: "))); break;
                case 9: buscarPorCodigo(); break;
                case 10: lista.mostrar(); break;
                case 11: lista.ordenarPorCodigo(); ok("Lista ordenada por codigo (ascendente)."); lista.mostrar(); break;
                case 12: intercambiarAlumnos(); break;
                case 13: System.out.println("Cantidad de alumnos: " + lista.contarNodos()); break;
                case 14: modificarAlumno(); break;
                case 99: cargarDatosPrueba(); break;
                case 0: System.out.println("Saliendo del sistema..."); break;
                default: System.out.println("[ERROR] Opcion no valida.");
            }
        } while (opcion != 0);
    }

    private void mostrarMenu() {
        System.out.println("\n================================================");
        System.out.println("        SISTEMA DE GESTION DE ALUMNOS");
        System.out.println("   LISTA CIRCULAR SIMPLEMENTE ENLAZADA");
        System.out.println("================================================");
        System.out.println("--- INSERCION ---");
        System.out.println(" 1. Insertar alumno al inicio");
        System.out.println(" 2. Insertar alumno al final");
        System.out.println(" 3. Insertar alumno en posicion X");
        System.out.println(" 4. Insertar alumno por referencia");
        System.out.println("--- ELIMINACION ---");
        System.out.println(" 5. Eliminar el primer alumno");
        System.out.println(" 6. Eliminar el ultimo alumno");
        System.out.println(" 7. Eliminar alumno en posicion X");
        System.out.println(" 8. Eliminar alumno por referencia (codigo)");
        System.out.println("--- CONSULTAS Y OPERACIONES ---");
        System.out.println(" 9. Buscar alumno por codigo");
        System.out.println("10. Mostrar todos los alumnos");
        System.out.println("11. Ordenar alumnos por codigo");
        System.out.println("12. Intercambiar dos alumnos");
        System.out.println("13. Mostrar cantidad de alumnos");
        System.out.println("14. Modificar datos de un alumno");
        System.out.println("---");
        System.out.println("99. Cargar datos de prueba");
        System.out.println(" 0. Salir del sistema");
        System.out.println("================================================");
    }

    // Opcion 3
    private void insertarEnPosicion() {
        int x = leerEntero("Posicion X (1 a " + (lista.contarNodos() + 1) + "): ");
        if (x < 1 || x > lista.contarNodos() + 1) {
            System.out.println("[ERROR] Posicion invalida.");
            return;
        }
        lista.insertarPosicion(x, leerAlumnoNuevo());
        ok("Alumno insertado en la posicion " + x + ".");
    }

    // Opcion 4
    private void insertarPorReferencia() {
        if (lista.estaVacia()) {
            System.out.println("[AVISO] La lista esta vacia: no hay alumno de referencia.");
            return;
        }
        String ref = leerTexto("Codigo del alumno de referencia: ");
        if (lista.buscar(ref) == null) {
            System.out.println("[ERROR] No existe el alumno de referencia " + ref + ".");
            return;
        }
        lista.insertarReferencia(ref, leerAlumnoNuevo());
        ok("Alumno insertado despues de " + ref + ".");
    }

    // Opcion 7
    private void eliminarEnPosicion() {
        if (lista.estaVacia()) {
            System.out.println("[AVISO] La lista esta vacia.");
            return;
        }
        int x = leerEntero("Posicion a eliminar (1 a " + lista.contarNodos() + "): ");
        Alumno eliminado = lista.eliminarPosicion(x);
        if (eliminado == null) {
            System.out.println("[ERROR] Posicion invalida.");
        } else {
            ok("Alumno eliminado: " + eliminado);
        }
    }

    // Opcion 9
    private void buscarPorCodigo() {
        String codigo = leerTexto("Codigo a buscar: ");
        Alumno encontrado = lista.buscar(codigo);
        if (encontrado == null) {
            System.out.println("[AVISO] No existe un alumno con el codigo " + codigo + ".");
            return;
        }
        System.out.println("[OK] Alumno encontrado");
        System.out.println("   Codigo   : " + encontrado.getCodigo());
        System.out.println("   Nombres  : " + encontrado.getNombres());
        System.out.println("   Carrera  : " + encontrado.getCarrera());
        System.out.println("   Semestre : " + encontrado.getSemestre());
    }

    // Opcion 12
    private void intercambiarAlumnos() {
        int x = leerEntero("Primera posicion: ");
        int y = leerEntero("Segunda posicion: ");
        if (lista.intercambiar(x, y)) {
            ok("Se intercambiaron las posiciones " + x + " y " + y + ".");
            lista.mostrar();
        } else {
            System.out.println("[ERROR] Posiciones invalidas.");
        }
    }

    // Opcion 14
    private void modificarAlumno() {
        String codigo = leerTexto("Codigo del alumno a modificar: ");
        if (lista.buscar(codigo) == null) {
            System.out.println("[AVISO] No existe un alumno con el codigo " + codigo + ".");
            return;
        }
        String nombres = leerTexto("Nuevos nombres: ");
        String carrera = leerTexto("Nueva carrera: ");
        int semestre = leerSemestre();
        lista.modificar(codigo, nombres, carrera, semestre);
        ok("Datos actualizados: " + lista.buscar(codigo));
    }

    // Opcion 99
    private void cargarDatosPrueba() {
        String[][] datos = {
            {"1003", "Pedro Rojas", "Sistemas", "5"},
            {"1001", "Carlos Quispe", "Civil", "3"},
            {"1004", "Lucia Torres", "Industrial", "7"},
            {"1002", "Maria Huaman", "Sistemas", "4"}};
        int cargados = 0;
        for (String[] d : datos) {
            if (lista.buscar(d[0]) == null) {
                lista.insertarFinal(new Alumno(d[0], d[1], d[2], Integer.parseInt(d[3])));
                cargados++;
            }
        }
        ok("Se cargaron " + cargados + " alumnos de prueba.");
        lista.mostrar();
    }

    // ---------------------------------------------------------------- lectura
    private Alumno leerAlumnoNuevo() {
        String codigo = leerTexto("Codigo: ");
        while (lista.buscar(codigo) != null) {
            System.out.println("[ERROR] El codigo " + codigo + " ya existe.");
            codigo = leerTexto("Codigo: ");
        }
        String nombres = leerTexto("Nombres y apellidos: ");
        String carrera = leerTexto("Carrera: ");
        int semestre = leerSemestre();
        return new Alumno(codigo, nombres, carrera, semestre);
    }

    private void informarEliminado(Alumno eliminado) {
        if (eliminado == null) {
            System.out.println("[AVISO] No se elimino: lista vacia o codigo inexistente.");
        } else {
            ok("Alumno eliminado: " + eliminado);
        }
    }

    private void ok(String mensaje) {
        System.out.println("[OK] " + mensaje);
    }

    private String leerTexto(String mensaje) {
        String texto;
        do {
            System.out.print(mensaje);
            texto = teclado.nextLine().trim();
        } while (texto.isEmpty());
        return texto;
    }

    private int leerEntero(String mensaje) {
        while (true) {
            try {
                return Integer.parseInt(leerTexto(mensaje));
            } catch (NumberFormatException e) {
                System.out.println("[ERROR] Ingrese un numero entero.");
            }
        }
    }

    private int leerSemestre() {
        int semestre = leerEntero("Semestre (1 a 10): ");
        while (semestre < 1 || semestre > 10) {
            System.out.println("[ERROR] El semestre debe estar entre 1 y 10.");
            semestre = leerEntero("Semestre (1 a 10): ");
        }
        return semestre;
    }
}
