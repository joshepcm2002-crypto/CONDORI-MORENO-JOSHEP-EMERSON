package DAO;

import Modelo.Alumno;
import Modelo.CNodo;

/**
 * Lista circular simplemente enlazada de alumnos.
 * p apunta al primer nodo y el ultimo nodo apunta otra vez a p (no hay null).
 * Con un solo nodo, ese nodo se apunta a si mismo. Las posiciones empiezan en 1.
 */
public class CListaCircular {

    private CNodo p;

    public CListaCircular() {
        p = null;
    }

    public boolean estaVacia() {
        return p == null;
    }

    // 1. Insertar alumno al inicio
    public void insertarInicio(Alumno alumno) {
        CNodo nuevo = new CNodo(alumno);
        if (p == null) {
            nuevo.setSig(nuevo);       // un solo nodo: se apunta a si mismo
            p = nuevo;
            return;
        }
        CNodo ultimo = ultimoNodo();
        nuevo.setSig(p);               // (1) el nuevo apunta al que era el primero
        ultimo.setSig(nuevo);          // (2) el ultimo cierra el circulo en el nuevo
        p = nuevo;                     // (3) p apunta al nuevo
    }

    // 2. Insertar alumno al final
    public void insertarFinal(Alumno alumno) {
        if (p == null) {
            insertarInicio(alumno);
            return;
        }
        CNodo nuevo = new CNodo(alumno);
        CNodo ultimo = ultimoNodo();
        nuevo.setSig(p);               // (1) el nuevo apunta al primero (cierra el circulo)
        ultimo.setSig(nuevo);          // (2) el que era ultimo apunta al nuevo
    }

    // 3. Insertar alumno en la posicion X (1 a cantidad + 1)
    public boolean insertarPosicion(int x, Alumno alumno) {
        int n = contarNodos();
        if (x < 1 || x > n + 1) {
            return false;
        }
        if (x == 1) {
            insertarInicio(alumno);
            return true;
        }
        CNodo q = p;
        for (int i = 1; i < x - 1; i++) {   // q se detiene en la posicion x - 1
            q = q.getSig();
        }
        CNodo nuevo = new CNodo(alumno);
        nuevo.setSig(q.getSig());           // (1) si x = n + 1, q.getSig() es p y el circulo se mantiene
        q.setSig(nuevo);                    // (2)
        return true;
    }

    // 4. Insertar alumno por referencia: despues del alumno con codigo ref
    public boolean insertarReferencia(String ref, Alumno alumno) {
        CNodo q = buscarNodo(ref);
        if (q == null) {
            return false;
        }
        CNodo nuevo = new CNodo(alumno);
        nuevo.setSig(q.getSig());   // (1) el nuevo apunta al siguiente de la referencia
        q.setSig(nuevo);            // (2) la referencia apunta al nuevo
        return true;
    }

    // 5. Eliminar el primer alumno
    public Alumno eliminarInicio() {
        if (p == null) {
            return null;
        }
        Alumno eliminado = p.getDato();
        if (p.getSig() == p) {      // un solo nodo
            p = null;
            return eliminado;
        }
        CNodo ultimo = ultimoNodo();
        p = p.getSig();             // (1) p pasa al segundo nodo
        ultimo.setSig(p);           // (2) el ultimo apunta al nuevo primero
        return eliminado;
    }

    // 6. Eliminar el ultimo alumno
    public Alumno eliminarFinal() {
        if (p == null) {
            return null;
        }
        if (p.getSig() == p) {
            return eliminarInicio();
        }
        CNodo q = p;
        while (q.getSig().getSig() != p) {   // q se detiene en el penultimo
            q = q.getSig();
        }
        Alumno eliminado = q.getSig().getDato();
        q.setSig(p);                          // el penultimo ahora cierra el circulo
        return eliminado;
    }

    // 7. Eliminar el alumno de la posicion X (1 a cantidad)
    public Alumno eliminarPosicion(int x) {
        if (x < 1 || x > contarNodos()) {
            return null;
        }
        if (x == 1) {
            return eliminarInicio();
        }
        CNodo q = p;
        for (int i = 1; i < x - 1; i++) {   // q se detiene en la posicion x - 1
            q = q.getSig();
        }
        CNodo borrar = q.getSig();
        q.setSig(borrar.getSig());          // el anterior se salta el nodo borrado
        return borrar.getDato();
    }

    // 8. Eliminar alumno por referencia (su codigo)
    public Alumno eliminarReferencia(String codigo) {
        if (p == null) {
            return null;
        }
        if (p.getDato().getCodigo().equalsIgnoreCase(codigo)) {
            return eliminarInicio();
        }
        CNodo ant = p;
        CNodo q = p.getSig();
        while (q != p && !q.getDato().getCodigo().equalsIgnoreCase(codigo)) {
            ant = q;                 // ant siempre va un nodo detras de q
            q = q.getSig();
        }
        if (q == p) {
            return null;             // dio la vuelta completa: no existe
        }
        ant.setSig(q.getSig());
        return q.getDato();
    }

    // 9. Buscar alumno por codigo (null si no existe)
    public Alumno buscar(String codigo) {
        CNodo q = buscarNodo(codigo);
        return q == null ? null : q.getDato();
    }

    // 10. Recorrer la lista circular mostrando todos los alumnos
    public void mostrar() {
        if (p == null) {
            System.out.println("[AVISO] La lista esta vacia.");
            return;
        }
        CNodo q = p;
        int pos = 1;
        String cadena = "p -> ";
        do {                         // do-while: el recorrido termina al volver a p
            System.out.println(pos + ". " + q.getDato());
            cadena += "[" + q.getDato().getCodigo() + "] -> ";
            q = q.getSig();
            pos++;
        } while (q != p);
        System.out.println(cadena + "(vuelve a " + p.getDato().getCodigo() + ")");
    }

    // 11. Ordenar alumnos por codigo de forma ascendente (burbuja intercambiando datos)
    public void ordenarPorCodigo() {
        if (p == null || p.getSig() == p) {
            return;
        }
        boolean cambio = true;
        while (cambio) {
            cambio = false;
            CNodo q = p;
            while (q.getSig() != p) {         // hasta el ultimo, sin volver a comparar con p
                if (q.getDato().getCodigo().compareToIgnoreCase(q.getSig().getDato().getCodigo()) > 0) {
                    intercambiarDatos(q, q.getSig());
                    cambio = true;
                }
                q = q.getSig();
            }
        }
    }

    // 12. Intercambiar los alumnos de dos posiciones
    public boolean intercambiar(int x, int y) {
        int n = contarNodos();
        if (x < 1 || y < 1 || x > n || y > n) {
            return false;
        }
        intercambiarDatos(nodoEn(x), nodoEn(y));
        return true;
    }

    // 13. Cantidad de alumnos (cuenta hasta volver a p)
    public int contarNodos() {
        if (p == null) {
            return 0;
        }
        int cantidad = 0;
        CNodo q = p;
        do {
            cantidad++;
            q = q.getSig();
        } while (q != p);
        return cantidad;
    }

    // 14. Modificar los datos de un alumno (el codigo no cambia)
    public boolean modificar(String codigo, String nombres, String carrera, int semestre) {
        CNodo q = buscarNodo(codigo);
        if (q == null) {
            return false;
        }
        q.getDato().setNombres(nombres);
        q.getDato().setCarrera(carrera);
        q.getDato().setSemestre(semestre);
        return true;
    }

    // ---------------------------------------------------------------- auxiliares
    private CNodo ultimoNodo() {
        CNodo q = p;
        while (q.getSig() != p) {   // el ultimo es el que apunta a p
            q = q.getSig();
        }
        return q;
    }

    private CNodo buscarNodo(String codigo) {
        if (p == null) {
            return null;
        }
        CNodo q = p;
        do {
            if (q.getDato().getCodigo().equalsIgnoreCase(codigo)) {
                return q;
            }
            q = q.getSig();
        } while (q != p);           // si vuelve a p, ya reviso todos
        return null;
    }

    private CNodo nodoEn(int x) {
        CNodo q = p;
        for (int i = 1; i < x; i++) {
            q = q.getSig();
        }
        return q;
    }

    private void intercambiarDatos(CNodo a, CNodo b) {
        Alumno temp = a.getDato();
        a.setDato(b.getDato());
        b.setDato(temp);
    }
}
