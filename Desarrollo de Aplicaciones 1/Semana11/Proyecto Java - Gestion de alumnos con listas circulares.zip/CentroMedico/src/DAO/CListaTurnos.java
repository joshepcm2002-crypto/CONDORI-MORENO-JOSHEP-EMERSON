package DAO;

import Modelo.CNodo;
import Modelo.Paciente;

/**
 * Lista circular simplemente enlazada con los pacientes pendientes de atencion.
 * inicio apunta al paciente que se atiende primero; el ultimo nodo apunta a inicio.
 * Las posiciones empiezan en 1.
 */
public class CListaTurnos {

    private CNodo inicio;
    private int atendidos;

    public boolean estaVacia() {
        return inicio == null;
    }

    public int getAtendidos() {
        return atendidos;
    }

    // A1. Registrar paciente al inicio
    public void registrarInicio(Paciente paciente) {
        CNodo nuevo = new CNodo(paciente);
        if (inicio == null) {
            nuevo.setSiguiente(nuevo);
        } else {
            nuevo.setSiguiente(inicio);
            ultimoNodo().setSiguiente(nuevo);
        }
        inicio = nuevo;
    }

    // A2. Registrar paciente al final
    public void registrarFinal(Paciente paciente) {
        if (inicio == null) {
            registrarInicio(paciente);
            return;
        }
        CNodo nuevo = new CNodo(paciente);
        CNodo ultimo = ultimoNodo();
        nuevo.setSiguiente(inicio);
        ultimo.setSiguiente(nuevo);
    }

    // A3. Insertar paciente en una posicion (1 a cantidad + 1)
    public boolean insertarEnPosicion(int pos, Paciente paciente) {
        if (pos < 1 || pos > cantidad() + 1) {
            return false;
        }
        if (pos == 1) {
            registrarInicio(paciente);
            return true;
        }
        CNodo anterior = nodoEn(pos - 1);
        CNodo nuevo = new CNodo(paciente);
        nuevo.setSiguiente(anterior.getSiguiente());
        anterior.setSiguiente(nuevo);
        return true;
    }

    // A4. Insertar paciente despues de otro (por codigo)
    public boolean insertarDespuesDe(String codigoReferencia, Paciente paciente) {
        CNodo ref = buscarNodo(codigoReferencia);
        if (ref == null) {
            return false;
        }
        CNodo nuevo = new CNodo(paciente);
        nuevo.setSiguiente(ref.getSiguiente());
        ref.setSiguiente(nuevo);
        return true;
    }

    // B1. Atender al siguiente paciente: sale de la lista y inicio avanza al siguiente
    public Paciente atenderSiguiente() {
        Paciente atendido = eliminarPrimero();
        if (atendido != null) {
            atendido.getTurno().setEstado("ATENDIDO");
            atendidos++;
        }
        return atendido;
    }

    // B2. Cancelar (eliminar) el turno de un paciente por su codigo
    public Paciente cancelarTurno(String codigo) {
        Paciente cancelado = eliminarPorCodigo(codigo);
        if (cancelado != null) {
            cancelado.getTurno().setEstado("CANCELADO");
        }
        return cancelado;
    }

    // B3. Eliminar el primer turno pendiente
    public Paciente eliminarPrimero() {
        if (inicio == null) {
            return null;
        }
        Paciente primero = inicio.getDato();
        if (inicio.getSiguiente() == inicio) {
            inicio = null;
            return primero;
        }
        CNodo ultimo = ultimoNodo();
        inicio = inicio.getSiguiente();
        ultimo.setSiguiente(inicio);
        return primero;
    }

    // B4. Eliminar el ultimo turno pendiente
    public Paciente eliminarUltimo() {
        if (inicio == null || inicio.getSiguiente() == inicio) {
            return eliminarPrimero();
        }
        CNodo q = inicio;
        while (q.getSiguiente().getSiguiente() != inicio) {
            q = q.getSiguiente();
        }
        Paciente ultimo = q.getSiguiente().getDato();
        q.setSiguiente(inicio);
        return ultimo;
    }

    // B5. Reprogramar: saca al paciente y lo vuelve a insertar en otra posicion
    public boolean reprogramar(String codigo, int nuevaPosicion) {
        int n = cantidad();
        if (buscarNodo(codigo) == null || nuevaPosicion < 1 || nuevaPosicion > n) {
            return false;
        }
        Paciente paciente = eliminarPorCodigo(codigo);
        return insertarEnPosicion(nuevaPosicion, paciente);
    }

    // C1. Buscar paciente por codigo
    public Paciente buscar(String codigo) {
        CNodo q = buscarNodo(codigo);
        return q == null ? null : q.getDato();
    }

    public boolean existeDni(String dni) {
        if (inicio == null) {
            return false;
        }
        CNodo q = inicio;
        do {
            if (q.getDato().getDni().equals(dni)) {
                return true;
            }
            q = q.getSiguiente();
        } while (q != inicio);
        return false;
    }

    // C2. Mostrar todos los pacientes pendientes (una vuelta completa)
    public void mostrarPendientes() {
        if (inicio == null) {
            System.out.println("[AVISO] No hay pacientes pendientes.");
            return;
        }
        CNodo q = inicio;
        int pos = 1;
        do {
            System.out.println(pos + ". " + q.getDato());
            q = q.getSiguiente();
            pos++;
        } while (q != inicio);
        System.out.println("(el ultimo apunta otra vez a " + inicio.getDato().getCodigo() + ")");
    }

    // C3. Cantidad de pacientes registrados (pendientes)
    public int cantidad() {
        if (inicio == null) {
            return 0;
        }
        int n = 0;
        CNodo q = inicio;
        do {
            n++;
            q = q.getSiguiente();
        } while (q != inicio);
        return n;
    }

    // C4. Proximo paciente a atender (no lo saca de la lista)
    public Paciente proximo() {
        return inicio == null ? null : inicio.getDato();
    }

    // D1. Ordenar por numero de turno (burbuja intercambiando datos)
    public void ordenarPorTurno() {
        if (inicio == null) {
            return;
        }
        boolean cambio = true;
        while (cambio) {
            cambio = false;
            CNodo q = inicio;
            while (q.getSiguiente() != inicio) {
                if (q.getDato().getTurno().getNumeroTurno() > q.getSiguiente().getDato().getTurno().getNumeroTurno()) {
                    intercambiarDatos(q, q.getSiguiente());
                    cambio = true;
                }
                q = q.getSiguiente();
            }
        }
    }

    // D2. Intercambiar las posiciones de dos pacientes
    public boolean intercambiar(int a, int b) {
        int n = cantidad();
        if (a < 1 || b < 1 || a > n || b > n) {
            return false;
        }
        intercambiarDatos(nodoEn(a), nodoEn(b));
        return true;
    }

    // D3. Modificar los datos de un paciente (el codigo no cambia)
    public boolean modificar(String codigo, String nombres, String apellidos, String especialidad, String fecha, String hora) {
        CNodo q = buscarNodo(codigo);
        if (q == null) {
            return false;
        }
        Paciente pac = q.getDato();
        pac.setNombres(nombres);
        pac.setApellidos(apellidos);
        pac.setEspecialidad(especialidad);
        pac.getTurno().setFecha(fecha);
        pac.getTurno().setHora(hora);
        return true;
    }

    // ---------------------------------------------------------------- auxiliares
    private Paciente eliminarPorCodigo(String codigo) {
        if (inicio == null) {
            return null;
        }
        if (inicio.getDato().getCodigo().equalsIgnoreCase(codigo)) {
            return eliminarPrimero();
        }
        CNodo anterior = inicio;
        CNodo actual = inicio.getSiguiente();
        while (actual != inicio && !actual.getDato().getCodigo().equalsIgnoreCase(codigo)) {
            anterior = actual;
            actual = actual.getSiguiente();
        }
        if (actual == inicio) {
            return null;
        }
        anterior.setSiguiente(actual.getSiguiente());
        return actual.getDato();
    }

    private CNodo ultimoNodo() {
        CNodo q = inicio;
        while (q.getSiguiente() != inicio) {
            q = q.getSiguiente();
        }
        return q;
    }

    private CNodo buscarNodo(String codigo) {
        if (inicio == null) {
            return null;
        }
        CNodo q = inicio;
        do {
            if (q.getDato().getCodigo().equalsIgnoreCase(codigo)) {
                return q;
            }
            q = q.getSiguiente();
        } while (q != inicio);
        return null;
    }

    private CNodo nodoEn(int pos) {
        CNodo q = inicio;
        for (int i = 1; i < pos; i++) {
            q = q.getSiguiente();
        }
        return q;
    }

    private void intercambiarDatos(CNodo a, CNodo b) {
        Paciente temp = a.getDato();
        a.setDato(b.getDato());
        b.setDato(temp);
    }
}
