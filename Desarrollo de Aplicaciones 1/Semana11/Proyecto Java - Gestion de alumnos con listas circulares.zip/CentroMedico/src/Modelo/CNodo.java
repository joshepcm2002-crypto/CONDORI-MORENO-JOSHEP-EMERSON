package Modelo;

/**
 * Nodo de la lista circular: dato (el paciente) y siguiente (el proximo nodo).
 * El siguiente del ultimo nodo apunta al primero.
 */
public class CNodo {

    private Paciente dato;
    private CNodo siguiente;

    public CNodo(Paciente dato) {
        this.dato = dato;
        this.siguiente = null;
    }

    public Paciente getDato() {
        return dato;
    }

    public void setDato(Paciente dato) {
        this.dato = dato;
    }

    public CNodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(CNodo siguiente) {
        this.siguiente = siguiente;
    }
}
