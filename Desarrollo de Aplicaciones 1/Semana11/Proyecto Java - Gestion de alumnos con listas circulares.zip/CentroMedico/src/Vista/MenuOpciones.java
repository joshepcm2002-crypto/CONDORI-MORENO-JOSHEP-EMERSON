package Vista;

import DAO.CListaTurnos;
import Modelo.Paciente;
import Modelo.Turno;
import java.util.Scanner;

/**
 * Menu del sistema de turnos del centro medico.
 * El numero de turno se asigna automaticamente en orden de registro.
 */
public class MenuOpciones {

    private final Scanner teclado = new Scanner(System.in);
    private final CListaTurnos lista = new CListaTurnos();
    private int siguienteTurno = 1;

    public void menu() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opcion: ");
            switch (opcion) {
                case 1: lista.registrarInicio(leerPaciente()); ok("Paciente registrado al inicio."); break;
                case 2: lista.registrarFinal(leerPaciente()); ok("Paciente registrado al final."); break;
                case 3: insertarEnPosicion(); break;
                case 4: insertarDespuesDe(); break;
                case 5: atender(); break;
                case 6: cancelar(); break;
                case 7: informar("Turno eliminado (primero): ", lista.eliminarPrimero()); break;
                case 8: informar("Turno eliminado (ultimo): ", lista.eliminarUltimo()); break;
                case 9: reprogramar(); break;
                case 10: buscar(); break;
                case 11: lista.mostrarPendientes(); break;
                case 12: System.out.println("Pacientes pendientes: " + lista.cantidad()
                        + " | Atendidos en la sesion: " + lista.getAtendidos()); break;
                case 13: proximo(); break;
                case 14: lista.ordenarPorTurno(); ok("Pacientes ordenados por numero de turno."); lista.mostrarPendientes(); break;
                case 15: intercambiar(); break;
                case 16: modificar(); break;
                case 99: cargarDatosPrueba(); break;
                case 0: System.out.println("Saliendo del sistema de turnos..."); break;
                default: System.out.println("[ERROR] Opcion no valida.");
            }
        } while (opcion != 0);
    }

    private void mostrarMenu() {
        System.out.println("\n==================================================");
        System.out.println("   GESTION DE TURNOS - CENTRO MEDICO (LISTA CIRCULAR)");
        System.out.println("==================================================");
        System.out.println(" A. REGISTRO DE PACIENTES");
        System.out.println("  1. Registrar paciente al inicio");
        System.out.println("  2. Registrar paciente al final");
        System.out.println("  3. Insertar paciente en una posicion");
        System.out.println("  4. Insertar paciente despues de otro (codigo)");
        System.out.println(" B. GESTION DE TURNOS");
        System.out.println("  5. Atender al siguiente paciente");
        System.out.println("  6. Cancelar turno por codigo");
        System.out.println("  7. Eliminar el primer turno pendiente");
        System.out.println("  8. Eliminar el ultimo turno pendiente");
        System.out.println("  9. Reprogramar paciente (cambiar de posicion)");
        System.out.println(" C. CONSULTAS");
        System.out.println(" 10. Buscar paciente por codigo");
        System.out.println(" 11. Mostrar pacientes pendientes");
        System.out.println(" 12. Cantidad de pacientes registrados");
        System.out.println(" 13. Proximo paciente a atender");
        System.out.println(" D. ADMINISTRACION");
        System.out.println(" 14. Ordenar por numero de turno");
        System.out.println(" 15. Intercambiar dos pacientes");
        System.out.println(" 16. Modificar datos de un paciente");
        System.out.println(" 99. Cargar datos de prueba");
        System.out.println("  0. Salir");
        System.out.println("==================================================");
    }

    private void insertarEnPosicion() {
        int pos = leerEntero("Posicion (1 a " + (lista.cantidad() + 1) + "): ");
        if (pos < 1 || pos > lista.cantidad() + 1) {
            System.out.println("[ERROR] Posicion invalida.");
            return;
        }
        lista.insertarEnPosicion(pos, leerPaciente());
        ok("Paciente insertado en la posicion " + pos + ".");
    }

    private void insertarDespuesDe() {
        String ref = leerTexto("Codigo del paciente de referencia: ");
        if (lista.buscar(ref) == null) {
            System.out.println("[ERROR] No existe el paciente " + ref + ".");
            return;
        }
        lista.insertarDespuesDe(ref, leerPaciente());
        ok("Paciente insertado despues de " + ref + ".");
    }

    private void atender() {
        Paciente p = lista.atenderSiguiente();
        if (p == null) {
            System.out.println("[AVISO] No hay pacientes por atender.");
            return;
        }
        System.out.println("[ATENCION] Pasa a consulta: " + p);
        Paciente sig = lista.proximo();
        System.out.println(sig == null ? "No quedan pacientes pendientes." : "Siguiente en espera: " + sig.getCodigo());
    }

    private void cancelar() {
        Paciente p = lista.cancelarTurno(leerTexto("Codigo del paciente que cancela: "));
        informar("Turno cancelado: ", p);
    }

    private void reprogramar() {
        String codigo = leerTexto("Codigo del paciente a reprogramar: ");
        if (lista.buscar(codigo) == null) {
            System.out.println("[ERROR] No existe el paciente " + codigo + ".");
            return;
        }
        int pos = leerEntero("Nueva posicion (1 a " + lista.cantidad() + "): ");
        if (lista.reprogramar(codigo, pos)) {
            ok("Paciente " + codigo + " reprogramado a la posicion " + pos + ".");
            lista.mostrarPendientes();
        } else {
            System.out.println("[ERROR] Posicion invalida.");
        }
    }

    private void buscar() {
        String codigo = leerTexto("Codigo a buscar: ");
        Paciente p = lista.buscar(codigo);
        System.out.println(p == null ? "[AVISO] No existe el paciente " + codigo + "." : "[OK] " + p);
    }

    private void proximo() {
        Paciente p = lista.proximo();
        System.out.println(p == null ? "[AVISO] No hay pacientes pendientes." : "[PROXIMO] " + p);
    }

    private void intercambiar() {
        int a = leerEntero("Primera posicion: ");
        int b = leerEntero("Segunda posicion: ");
        if (lista.intercambiar(a, b)) {
            ok("Se intercambiaron las posiciones " + a + " y " + b + ".");
            lista.mostrarPendientes();
        } else {
            System.out.println("[ERROR] Posiciones invalidas.");
        }
    }

    private void modificar() {
        String codigo = leerTexto("Codigo del paciente a modificar: ");
        if (lista.buscar(codigo) == null) {
            System.out.println("[AVISO] No existe el paciente " + codigo + ".");
            return;
        }
        lista.modificar(codigo, leerTexto("Nombres: "), leerTexto("Apellidos: "), leerTexto("Especialidad: "),
                leerFecha(), leerHora());
        ok("Datos actualizados: " + lista.buscar(codigo));
    }

    private void cargarDatosPrueba() {
        String[][] datos = {
            {"P03", "Luis", "Ramos", "45781236", "Cardiologia", "2026-11-12", "08:30"},
            {"P01", "Ana", "Flores", "70214589", "Pediatria", "2026-11-12", "08:45"},
            {"P04", "Jorge", "Vega", "41236598", "Traumatologia", "2026-11-12", "09:00"},
            {"P02", "Elena", "Cruz", "76321458", "Cardiologia", "2026-11-12", "09:15"}};
        for (String[] d : datos) {
            if (lista.buscar(d[0]) == null && !lista.existeDni(d[3])) {
                lista.registrarFinal(new Paciente(d[0], d[1], d[2], d[3], d[4], new Turno(siguienteTurno++, d[5], d[6])));
            }
        }
        ok("Datos de prueba cargados.");
        lista.mostrarPendientes();
    }

    // ---------------------------------------------------------------- lectura
    private Paciente leerPaciente() {
        String codigo = leerTexto("Codigo del paciente: ");
        while (lista.buscar(codigo) != null) {
            System.out.println("[ERROR] El codigo " + codigo + " ya esta registrado.");
            codigo = leerTexto("Codigo del paciente: ");
        }
        String nombres = leerTexto("Nombres: ");
        String apellidos = leerTexto("Apellidos: ");
        String dni = leerTexto("DNI (8 digitos): ");
        while (!dni.matches("\\d{8}") || lista.existeDni(dni)) {
            System.out.println("[ERROR] DNI invalido o ya registrado.");
            dni = leerTexto("DNI (8 digitos): ");
        }
        String especialidad = leerTexto("Especialidad: ");
        Turno turno = new Turno(siguienteTurno++, leerFecha(), leerHora());
        System.out.println("Numero de turno asignado: " + turno.getNumeroTurno());
        return new Paciente(codigo, nombres, apellidos, dni, especialidad, turno);
    }

    private String leerFecha() {
        String f = leerTexto("Fecha (AAAA-MM-DD): ");
        while (!f.matches("\\d{4}-\\d{2}-\\d{2}")) {
            f = leerTexto("[ERROR] Formato AAAA-MM-DD: ");
        }
        return f;
    }

    private String leerHora() {
        String h = leerTexto("Hora (HH:MM): ");
        while (!h.matches("([01]\\d|2[0-3]):[0-5]\\d")) {
            h = leerTexto("[ERROR] Formato HH:MM: ");
        }
        return h;
    }

    private void informar(String prefijo, Paciente p) {
        System.out.println(p == null ? "[AVISO] No se encontro el paciente o la lista esta vacia." : "[OK] " + prefijo + p);
    }

    private void ok(String mensaje) {
        System.out.println("[OK] " + mensaje);
    }

    private String leerTexto(String mensaje) {
        String texto;
        do {
            System.out.print(mensaje);
            texto = teclado.nextLine().trim();
        } while (texto.isEmpty());
        return texto;
    }

    private int leerEntero(String mensaje) {
        while (true) {
            try {
                return Integer.parseInt(leerTexto(mensaje));
            } catch (NumberFormatException e) {
                System.out.println("[ERROR] Ingrese un numero entero.");
            }
        }
    }
}
