package Vista;

/**
 * SEMANA 11 - Proyecto 02
 * Sistema de gestion de turnos de atencion en un centro medico (lista circular).
 */
public class Principal {

    public static void main(String[] args) {
        new MenuOpciones().menu();
    }
}
