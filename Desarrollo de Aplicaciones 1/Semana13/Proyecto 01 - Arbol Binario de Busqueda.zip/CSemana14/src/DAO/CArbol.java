package DAO;

import Modelo.CNodo;
import Modelo.Producto;
import java.util.ArrayList;
import java.util.List;

public class CArbol {
    private CNodo raiz;

    public CArbol() {
        this.raiz = null;
    }

    public CNodo getRaiz() {
        return raiz;
    }

    public boolean estaVacio() {
        return raiz == null;
    }

    // Requerimiento 1 y 2: Insertar producto ordenado por codigo unico en el BST
    public boolean insertar(Producto producto) {
        if (buscar(producto.getCodigo()) != null) {
            return false;
        }
        raiz = insertarRec(raiz, producto);
        return true;
    }

    private CNodo insertarRec(CNodo actual, Producto producto) {
        if (actual == null) {
            return new CNodo(producto);
        }
        if (producto.getCodigo() < actual.getDato().getCodigo()) {
            actual.setIzquierdo(insertarRec(actual.getIzquierdo(), producto));
        } else if (producto.getCodigo() > actual.getDato().getCodigo()) {
            actual.setDerecho(insertarRec(actual.getDerecho(), producto));
        }
        return actual;
    }

    // Requerimiento 3: Buscar producto mediante su codigo en el arbol binario
    public Producto buscar(int codigo) {
        CNodo nodo = buscarRec(raiz, codigo);
        return (nodo != null) ? nodo.getDato() : null;
    }

    private CNodo buscarRec(CNodo actual, int codigo) {
        if (actual == null) {
            return null;
        }
        if (codigo == actual.getDato().getCodigo()) {
            return actual;
        }
        if (codigo < actual.getDato().getCodigo()) {
            return buscarRec(actual.getIzquierdo(), codigo);
        } else {
            return buscarRec(actual.getDerecho(), codigo);
        }
    }

    // Requerimiento 4: Actualizar la informacion de un producto registrado
    public boolean actualizar(int codigo, String nombre, String categoria, String marca,
                              double precio, int stock, String fechaRegistro) {
        CNodo nodo = buscarRec(raiz, codigo);
        if (nodo == null) {
            return false;
        }
        Producto p = nodo.getDato();
        p.setNombre(nombre);
        p.setCategoria(categoria);
        p.setMarca(marca);
        p.setPrecio(precio);
        p.setStock(stock);
        p.setFechaRegistro(fechaRegistro);
        return true;
    }

    // Requerimiento 5: Eliminar productos considerando los 3 casos:
    // Caso 1: Nodo hoja | Caso 2: Nodo con un hijo | Caso 3: Nodo con dos hijos
    public boolean eliminar(int codigo) {
        if (buscar(codigo) == null) {
            return false;
        }
        raiz = eliminarRec(raiz, codigo);
        return true;
    }

    private CNodo eliminarRec(CNodo actual, int codigo) {
        if (actual == null) {
            return null;
        }
        if (codigo < actual.getDato().getCodigo()) {
            actual.setIzquierdo(eliminarRec(actual.getIzquierdo(), codigo));
        } else if (codigo > actual.getDato().getCodigo()) {
            actual.setDerecho(eliminarRec(actual.getDerecho(), codigo));
        } else {
            // Caso 1: Nodo hoja
            if (actual.getIzquierdo() == null && actual.getDerecho() == null) {
                return null;
            }
            // Caso 2: Nodo con un hijo
            if (actual.getIzquierdo() == null) {
                return actual.getDerecho();
            }
            if (actual.getDerecho() == null) {
                return actual.getIzquierdo();
            }
            // Caso 3: Nodo con dos hijos (sucesor inorden: minimo del subarbol derecho)
            CNodo sucesor = obtenerNodoMinimo(actual.getDerecho());
            actual.setDato(sucesor.getDato());
            actual.setDerecho(eliminarRec(actual.getDerecho(), sucesor.getDato().getCodigo()));
        }
        return actual;
    }

    // Requerimiento 6: Recorridos Inorden, Preorden y Postorden
    public List<Producto> recorridoInorden() {
        List<Producto> lista = new ArrayList<>();
        inordenRec(raiz, lista);
        return lista;
    }

    private void inordenRec(CNodo actual, List<Producto> lista) {
        if (actual != null) {
            inordenRec(actual.getIzquierdo(), lista);
            lista.add(actual.getDato());
            inordenRec(actual.getDerecho(), lista);
        }
    }

    public List<Producto> recorridoPreorden() {
        List<Producto> lista = new ArrayList<>();
        preordenRec(raiz, lista);
        return lista;
    }

    private void preordenRec(CNodo actual, List<Producto> lista) {
        if (actual != null) {
            lista.add(actual.getDato());
            preordenRec(actual.getIzquierdo(), lista);
            preordenRec(actual.getDerecho(), lista);
        }
    }

    public List<Producto> recorridoPostorden() {
        List<Producto> lista = new ArrayList<>();
        postordenRec(raiz, lista);
        return lista;
    }

    private void postordenRec(CNodo actual, List<Producto> lista) {
        if (actual != null) {
            postordenRec(actual.getIzquierdo(), lista);
            postordenRec(actual.getDerecho(), lista);
            lista.add(actual.getDato());
        }
    }

    // Requerimiento 7: Obtener producto con codigo menor y codigo mayor
    public Producto obtenerMinimo() {
        if (raiz == null) {
            return null;
        }
        return obtenerNodoMinimo(raiz).getDato();
    }

    private CNodo obtenerNodoMinimo(CNodo nodo) {
        CNodo actual = nodo;
        while (actual.getIzquierdo() != null) {
            actual = actual.getIzquierdo();
        }
        return actual;
    }

    public Producto obtenerMaximo() {
        if (raiz == null) {
            return null;
        }
        CNodo actual = raiz;
        while (actual.getDerecho() != null) {
            actual = actual.getDerecho();
        }
        return actual.getDato();
    }

    // Requerimiento 8: Reporte de productos ordenados ascendentemente por codigo
    public List<Producto> obtenerReporteAscendente() {
        return recorridoInorden();
    }

    // Requerimiento 9: Identificar productos con stock inferior a un limite
    public List<Producto> buscarBajoStock(int limite) {
        List<Producto> lista = new ArrayList<>();
        buscarBajoStockRec(raiz, limite, lista);
        return lista;
    }

    private void buscarBajoStockRec(CNodo actual, int limite, List<Producto> lista) {
        if (actual != null) {
            buscarBajoStockRec(actual.getIzquierdo(), limite, lista);
            if (actual.getDato().getStock() < limite) {
                lista.add(actual.getDato());
            }
            buscarBajoStockRec(actual.getDerecho(), limite, lista);
        }
    }

    // Requerimiento 10: Calcular el valor total del inventario (precio * stock)
    public double calcularValorTotalInventario() {
        return calcularValorRec(raiz);
    }

    private double calcularValorRec(CNodo actual) {
        if (actual == null) {
            return 0.0;
        }
        return actual.getDato().getValorTotal()
                + calcularValorRec(actual.getIzquierdo())
                + calcularValorRec(actual.getDerecho());
    }

    public int contarNodos() {
        return contarNodosRec(raiz);
    }

    private int contarNodosRec(CNodo actual) {
        if (actual == null) {
            return 0;
        }
        return 1 + contarNodosRec(actual.getIzquierdo()) + contarNodosRec(actual.getDerecho());
    }

    public String generarEstructuraVisual() {
        if (raiz == null) {
            return "El arbol binario de busqueda esta vacio.";
        }
        StringBuilder sb = new StringBuilder();
        generarEstructuraRec(raiz, "", true, sb);
        return sb.toString();
    }

    private void generarEstructuraRec(CNodo nodo, String prefijo, boolean esUltimo, StringBuilder sb) {
        if (nodo != null) {
            sb.append(prefijo);
            sb.append(esUltimo ? "\\-- " : "|-- ");
            sb.append("[").append(nodo.getDato().getCodigo()).append("] ")
              .append(nodo.getDato().getNombre())
              .append(" (Stock: ").append(nodo.getDato().getStock()).append(")\n");

            List<CNodo> hijos = new ArrayList<>();
            if (nodo.getIzquierdo() != null) hijos.add(nodo.getIzquierdo());
            if (nodo.getDerecho() != null) hijos.add(nodo.getDerecho());

            for (int i = 0; i < hijos.size(); i++) {
                CNodo hijo = hijos.get(i);
                String lado = (hijo == nodo.getIzquierdo()) ? "(Izq) " : "(Der) ";
                generarEstructuraRec(hijo, prefijo + (esUltimo ? "    " : "|   ") + lado, i == hijos.size() - 1, sb);
            }
        }
    }

    public void cargarDatosPrueba() {
        insertar(new Producto(500, "Laptop ThinkPad E14", "Computadoras", "Lenovo", 3450.00, 12, "2026-11-23"));
        insertar(new Producto(250, "Mouse Inalambrico MX Master 3S", "Perifericos", "Logitech", 380.00, 4, "2026-11-23"));
        insertar(new Producto(750, "Monitor 27 pulgadas 4K IPS", "Monitores", "LG", 1450.00, 8, "2026-11-23"));
        insertar(new Producto(120, "Teclado Mecanico RGB", "Perifericos", "HyperX", 290.00, 3, "2026-11-23"));
        insertar(new Producto(350, "Disco SSD NVMe 1TB", "Almacenamiento", "Samsung", 420.00, 18, "2026-11-23"));
        insertar(new Producto(620, "Audifonos Studio Pro", "Audio", "Sony", 650.00, 2, "2026-11-23"));
        insertar(new Producto(890, "Impresora Multifuncional EcoTank", "Impresion", "Epson", 1120.00, 6, "2026-11-23"));
    }
}
