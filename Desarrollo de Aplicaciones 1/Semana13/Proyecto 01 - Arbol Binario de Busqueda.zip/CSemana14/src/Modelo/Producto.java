package Modelo;

import java.util.Locale;

public class Producto {
    private int codigo;
    private String nombre;
    private String categoria;
    private String marca;
    private double precio;
    private int stock;
    private String fechaRegistro;

    public Producto() {
    }

    public Producto(int codigo, String nombre, String categoria, String marca,
                    double precio, int stock, String fechaRegistro) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.categoria = categoria;
        this.marca = marca;
        this.precio = precio;
        this.stock = stock;
        this.fechaRegistro = fechaRegistro;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public double getValorTotal() {
        return this.precio * this.stock;
    }

    @Override
    public String toString() {
        return String.format(
            Locale.US,
            "Producto [Codigo: %d | Nombre: %s | Categoria: %s | Marca: %s | Precio: S/. %.2f | Stock: %d | Fecha: %s]",
            codigo, nombre, categoria, marca, precio, stock, fechaRegistro
        );
    }
}
