package Modelo;

public class CNodo {
    private Producto dato;
    private CNodo izquierdo;
    private CNodo derecho;

    public CNodo(Producto dato) {
        this.dato = dato;
        this.izquierdo = null;
        this.derecho = null;
    }

    public Producto getDato() {
        return dato;
    }

    public void setDato(Producto dato) {
        this.dato = dato;
    }

    public CNodo getIzquierdo() {
        return izquierdo;
    }

    public void setIzquierdo(CNodo izquierdo) {
        this.izquierdo = izquierdo;
    }

    public CNodo getDerecho() {
        return derecho;
    }

    public void setDerecho(CNodo derecho) {
        this.derecho = derecho;
    }
}
