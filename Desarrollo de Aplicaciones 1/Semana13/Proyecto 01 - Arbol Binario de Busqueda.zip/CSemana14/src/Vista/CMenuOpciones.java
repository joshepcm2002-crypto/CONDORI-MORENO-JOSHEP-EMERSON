package Vista;

import DAO.CArbol;
import Modelo.Producto;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class CMenuOpciones {
    private static final Scanner sc = new Scanner(System.in);
    private static final CArbol arbol = new CArbol();

    public static void mostrarMenu() {
        int opcion;
        do {
            System.out.println("\n================================================");
            System.out.println(" SISTEMA DE GESTION DE PRODUCTOS");
            System.out.println(" ARBOL BINARIO DE BUSQUEDA (BST)");
            System.out.println("================================================");
            System.out.println("1.  Registrar producto");
            System.out.println("2.  Buscar producto por codigo");
            System.out.println("3.  Actualizar informacion de producto");
            System.out.println("4.  Eliminar producto por codigo");
            System.out.println("5.  Mostrar recorrido Inorden");
            System.out.println("6.  Mostrar recorrido Preorden");
            System.out.println("7.  Mostrar recorrido Postorden");
            System.out.println("8.  Mostrar producto con codigo menor y mayor");
            System.out.println("9.  Generar reporte ascendente por codigo");
            System.out.println("10. Identificar productos con stock bajo");
            System.out.println("11. Calcular valor total del inventario");
            System.out.println("12. Mostrar estructura visual del arbol");
            System.out.println("13. Cargar datos de prueba");
            System.out.println("0.  Salir");
            System.out.println("================================================");
            System.out.print("Seleccione una opcion: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1:
                    registrarProducto();
                    break;
                case 2:
                    buscarProducto();
                    break;
                case 3:
                    actualizarProducto();
                    break;
                case 4:
                    eliminarProducto();
                    break;
                case 5:
                    imprimirLista(arbol.recorridoInorden(), "RECORRIDO INORDEN (IZQUIERDO - RAIZ - DERECHO)");
                    break;
                case 6:
                    imprimirLista(arbol.recorridoPreorden(), "RECORRIDO PREORDEN (RAIZ - IZQUIERDO - DERECHO)");
                    break;
                case 7:
                    imprimirLista(arbol.recorridoPostorden(), "RECORRIDO POSTORDEN (IZQUIERDO - DERECHO - RAIZ)");
                    break;
                case 8:
                    mostrarMinimoYMaximo();
                    break;
                case 9:
                    generarReporteAscendente();
                    break;
                case 10:
                    identificarBajoStock();
                    break;
                case 11:
                    calcularValorTotal();
                    break;
                case 12:
                    System.out.println("\n--- ESTRUCTURA DEL ARBOL BINARIO DE BUSQUEDA ---");
                    System.out.println(arbol.generarEstructuraVisual());
                    break;
                case 13:
                    arbol.cargarDatosPrueba();
                    System.out.println("Datos de prueba cargados correctamente en el arbol.");
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opcion no valida. Intente nuevamente.");
            }
        } while (opcion != 0);
    }

    private static void registrarProducto() {
        System.out.println("\n--- REGISTRAR NUEVO PRODUCTO ---");
        System.out.print("Codigo del producto (entero unico): ");
        int codigo = leerEntero();
        if (arbol.buscar(codigo) != null) {
            System.out.println("Error: Ya existe un producto registrado con el codigo " + codigo + ".");
            return;
        }
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Categoria: ");
        String categoria = sc.nextLine();
        System.out.print("Marca: ");
        String marca = sc.nextLine();
        System.out.print("Precio (S/.): ");
        double precio = leerDouble();
        System.out.print("Cantidad en stock: ");
        int stock = leerEntero();
        System.out.print("Fecha de registro (AAAA-MM-DD): ");
        String fecha = sc.nextLine();

        Producto nuevo = new Producto(codigo, nombre, categoria, marca, precio, stock, fecha);
        if (arbol.insertar(nuevo)) {
            System.out.println("Producto registrado e insertado en el arbol correctamente.");
        } else {
            System.out.println("No se pudo registrar el producto.");
        }
    }

    private static void buscarProducto() {
        if (arbol.estaVacio()) {
            System.out.println("El arbol esta vacio.");
            return;
        }
        System.out.print("\nIngrese el codigo del producto a buscar: ");
        int codigo = leerEntero();
        Producto p = arbol.buscar(codigo);
        if (p != null) {
            System.out.println("Producto encontrado:");
            System.out.println(p);
        } else {
            System.out.println("No se encontro ningun producto con el codigo " + codigo + ".");
        }
    }

    private static void actualizarProducto() {
        if (arbol.estaVacio()) {
            System.out.println("El arbol esta vacio.");
            return;
        }
        System.out.print("\nIngrese el codigo del producto a actualizar: ");
        int codigo = leerEntero();
        Producto existente = arbol.buscar(codigo);
        if (existente == null) {
            System.out.println("No existe un producto con el codigo " + codigo + ".");
            return;
        }
        System.out.println("Datos actuales: " + existente);
        System.out.print("Nuevo nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Nueva categoria: ");
        String categoria = sc.nextLine();
        System.out.print("Nueva marca: ");
        String marca = sc.nextLine();
        System.out.print("Nuevo precio (S/.): ");
        double precio = leerDouble();
        System.out.print("Nueva cantidad en stock: ");
        int stock = leerEntero();
        System.out.print("Nueva fecha de registro (AAAA-MM-DD): ");
        String fecha = sc.nextLine();

        if (arbol.actualizar(codigo, nombre, categoria, marca, precio, stock, fecha)) {
            System.out.println("Producto actualizado correctamente.");
        }
    }

    private static void eliminarProducto() {
        if (arbol.estaVacio()) {
            System.out.println("El arbol esta vacio.");
            return;
        }
        System.out.print("\nIngrese el codigo del producto a eliminar: ");
        int codigo = leerEntero();
        if (arbol.eliminar(codigo)) {
            System.out.println("Producto con codigo " + codigo + " eliminado del arbol correctamente.");
        } else {
            System.out.println("No se encontro un producto con el codigo " + codigo + ".");
        }
    }

    private static void mostrarMinimoYMaximo() {
        if (arbol.estaVacio()) {
            System.out.println("El arbol esta vacio.");
            return;
        }
        Producto min = arbol.obtenerMinimo();
        Producto max = arbol.obtenerMaximo();
        System.out.println("\n--- EXTREMOS DEL ARBOL BINARIO ---");
        System.out.println("Producto con codigo MENOR: " + min);
        System.out.println("Producto con codigo MAYOR: " + max);
    }

    private static void generarReporteAscendente() {
        List<Producto> lista = arbol.obtenerReporteAscendente();
        if (lista.isEmpty()) {
            System.out.println("No hay productos registrados para generar el reporte.");
            return;
        }
        System.out.println("\n==========================================================================================================");
        System.out.println("                           REPORTE DE PRODUCTOS ORDENADOS ASCENDENTEMENTE POR CODIGO                      ");
        System.out.println("==========================================================================================================");
        System.out.printf("%-8s %-30s %-16s %-12s %-12s %-8s %-12s%n",
                "CODIGO", "NOMBRE", "CATEGORIA", "MARCA", "PRECIO(S/.)", "STOCK", "FECHA");
        System.out.println("----------------------------------------------------------------------------------------------------------");
        for (Producto p : lista) {
            System.out.printf(Locale.US, "%-8d %-30s %-16s %-12s %-12.2f %-8d %-12s%n",
                    p.getCodigo(),
                    recortar(p.getNombre(), 29),
                    recortar(p.getCategoria(), 15),
                    recortar(p.getMarca(), 11),
                    p.getPrecio(),
                    p.getStock(),
                    p.getFechaRegistro());
        }
        System.out.println("==========================================================================================================");
    }

    private static void identificarBajoStock() {
        if (arbol.estaVacio()) {
            System.out.println("El arbol esta vacio.");
            return;
        }
        System.out.print("\nIngrese el limite minimo de stock: ");
        int limite = leerEntero();
        List<Producto> bajos = arbol.buscarBajoStock(limite);
        if (bajos.isEmpty()) {
            System.out.println("No hay productos con stock inferior a " + limite + " unidades.");
        } else {
            System.out.println("\n--- PRODUCTOS CON STOCK INFERIOR A " + limite + " UNIDADES ---");
            for (Producto p : bajos) {
                System.out.println(p);
            }
        }
    }

    private static void calcularValorTotal() {
        if (arbol.estaVacio()) {
            System.out.println("El arbol esta vacio. Valor total: S/. 0.00");
            return;
        }
        double total = arbol.calcularValorTotalInventario();
        System.out.println("\n--- VALOR TOTAL DEL INVENTARIO ---");
        System.out.println("Total de productos registrados: " + arbol.contarNodos());
        System.out.printf(Locale.US, "Valor total del inventario: S/. %,.2f%n", total);
    }

    private static void imprimirLista(List<Producto> lista, String titulo) {
        System.out.println("\n--- " + titulo + " ---");
        if (lista.isEmpty()) {
            System.out.println("El arbol esta vacio.");
            return;
        }
        for (Producto p : lista) {
            System.out.println(p);
        }
    }

    private static String recortar(String texto, int max) {
        if (texto == null) return "";
        return texto.length() <= max ? texto : texto.substring(0, max - 3) + "...";
    }

    private static int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un numero entero valido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }

    private static double leerDouble() {
        while (!sc.hasNextDouble()) {
            System.out.print("Ingrese un valor numerico valido: ");
            sc.next();
        }
        double valor = sc.nextDouble();
        sc.nextLine();
        return valor;
    }
}
