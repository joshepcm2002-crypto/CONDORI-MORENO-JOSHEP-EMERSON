package Vista;

public class Principal {
    public static void main(String[] args) {
        CMenuOpciones.mostrarMenu();
    }
}
