# Sistema de Lista Doblemente Enlazada (ClistaDoble.java)
Proyecto académico de Algoritmos y Estructura de Datos.
Contiene la implementación completa de la lista doblemente enlazada con 18 métodos y su respectiva documentación técnica.
