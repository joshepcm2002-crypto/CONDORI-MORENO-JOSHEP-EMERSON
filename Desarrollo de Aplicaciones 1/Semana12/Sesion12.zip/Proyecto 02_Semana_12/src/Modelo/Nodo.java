package Modelo;

public class Nodo {
    public Alumno dato;
    public Nodo anterior;
    public Nodo siguiente;

    public Nodo(Alumno dato) {
        this.dato = dato;
        this.anterior = null;
        this.siguiente = null;
    }
}
