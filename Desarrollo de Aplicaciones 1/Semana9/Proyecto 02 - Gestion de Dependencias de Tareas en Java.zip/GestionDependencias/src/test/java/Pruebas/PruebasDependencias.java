package Pruebas;

import DAO.DependenciasDAO;
import Modelo.ProyectoModelo;
import Modelo.TareaModelo;
import Modelo.TareaModelo.Estado;
import Vista.DependenciasVista;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Scanner;

/** Pruebas ejecutables sin librerías externas; no requieren activar -ea. */
public final class PruebasDependencias {
    private static int pruebas;

    private PruebasDependencias() { }

    public static void main(String[] args) {
        probarRegistroYValidacion();
        probarRecorridosYBloqueo();
        probarDiamanteYCiclos();
        probarVista();
        System.out.println("Pruebas de GestionDependencias superadas: " + pruebas);
    }

    private static void probarRegistroYValidacion() {
        DependenciasDAO dao = new DependenciasDAO();
        igual(dao.consultarTareas().size(), 0, "Proyecto inicialmente vacío");
        igual(dao.detectarCiclo(), List.of(), "Grafo vacío sin ciclos");
        igual(dao.identificarTareasBloqueadas(), List.of(), "Grafo vacío sin bloqueadas");
        exigir(dao.generarReporte().contains("Total: 0"), "Reporte vacío");
        TareaModelo tarea = dao.registrarTarea(" a ", "  Autenticación  ", Estado.PENDIENTE);
        igual(tarea.getCodigo(), "A", "Normalización del código");
        igual(tarea.getDescripcion(), "Autenticación", "Descripción sin bordes vacíos");
        igual(tarea.getEstado(), Estado.PENDIENTE, "Estado registrado");
        falla(IllegalArgumentException.class, () -> dao.registrarTarea("A", "Otra", Estado.COMPLETADA),
                "Código duplicado");
        falla(IllegalArgumentException.class, () -> dao.registrarTarea(null, "Otra", Estado.COMPLETADA),
                "Código nulo");
        falla(IllegalArgumentException.class, () -> dao.registrarTarea(" ", "Otra", Estado.COMPLETADA),
                "Código vacío");
        falla(IllegalArgumentException.class, () -> dao.registrarTarea("B", " ", Estado.COMPLETADA),
                "Descripción vacía");
        falla(IllegalArgumentException.class, () -> dao.registrarTarea("B", null, Estado.COMPLETADA),
                "Descripción nula");
        falla(IllegalArgumentException.class, () -> dao.registrarTarea("B", "Otra", null),
                "Estado nulo");
        falla(IllegalArgumentException.class, () -> dao.registrarDependencia("A", "Z"),
                "Prerrequisito inexistente");
        falla(IllegalArgumentException.class, () -> dao.registrarDependencia("Z", "A"),
                "Tarea inexistente");
        falla(IllegalArgumentException.class, () -> dao.consultarDependenciasDirectas("Z"),
                "Consulta inexistente");
        falla(IllegalArgumentException.class, () -> dao.calcularProfundidad("Z"),
                "Profundidad inexistente");
        falla(IllegalArgumentException.class, () -> dao.cambiarEstado("A", null), "Cambio a estado nulo");
        falla(IllegalArgumentException.class, () -> new DependenciasDAO((ProyectoModelo) null),
                "Proyecto nulo");
        falla(UnsupportedOperationException.class, () -> dao.consultarTareas().clear(),
                "Lista devuelta no modificable");
        igual(dao.consultarTareas().size(), 1, "Validaciones no alteran los datos");
    }

    private static void probarRecorridosYBloqueo() {
        DependenciasDAO dao = new DependenciasDAO();
        dao.registrarTarea("A", "Pruebas", Estado.PENDIENTE);
        dao.registrarTarea("B", "Ventas", Estado.COMPLETADA);
        dao.registrarTarea("C", "Inventario", Estado.PENDIENTE);
        dao.registrarTarea("D", "Autenticación", Estado.COMPLETADA);
        dao.registrarDependencia("A", "B");
        dao.registrarDependencia("B", "C");
        dao.registrarDependencia("B", "D");
        igual(codigos(dao.consultarDependenciasDirectas("a")), List.of("B"), "RF03 directas");
        igual(codigos(dao.consultarDependenciasIndirectas("A")), List.of("C", "D"),
                "RF04 indirectas recursivas");
        igual(dao.consultarDependenciasIndirectas("D").size(), 0, "Hoja sin indirectas");
        igual(dao.calcularProfundidad("D"), 0, "Caso base: cero enlaces");
        igual(dao.calcularProfundidad("B"), 1, "Profundidad de B");
        igual(dao.calcularProfundidad("A"), 2, "RF05 cadena de dos enlaces");
        igual(codigos(dao.identificarTareasBloqueadas()), List.of("A"),
                "RF07 bloqueo transitivo, tarea completada no bloqueada");
        String reporte = dao.generarReporte();
        exigir(reporte.contains("Total: 4") && reporte.contains("Pendientes: 2")
                && reporte.contains("Completadas: 2")
                && reporte.contains("Bloqueadas (subconjunto de pendientes): 1"), "RF08 reporte");
        dao.cambiarEstado("C", Estado.COMPLETADA);
        igual(dao.identificarTareasBloqueadas().size(), 0, "Completar prerrequisito desbloquea");
        dao.cambiarEstado("B", Estado.PENDIENTE);
        igual(codigos(dao.identificarTareasBloqueadas()), List.of("A"), "Prerrequisito directo pendiente");
        dao.cambiarEstado("A", Estado.COMPLETADA);
        igual(dao.identificarTareasBloqueadas().size(), 0, "Completada no se clasifica bloqueada");
        falla(IllegalArgumentException.class, () -> dao.registrarDependencia("A", "B"),
                "No duplicar aristas");
        igual(dao.consultarDependenciasDirectas("A").size(), 1, "Arista intacta tras duplicado");
    }

    private static void probarDiamanteYCiclos() {
        DependenciasDAO dao = new DependenciasDAO();
        for (String codigo : List.of("A", "B", "C", "D", "Z")) {
            dao.registrarTarea(codigo, "Tarea " + codigo, Estado.PENDIENTE);
        }
        dao.registrarDependencia("A", "B");
        dao.registrarDependencia("A", "C");
        dao.registrarDependencia("B", "D");
        dao.registrarDependencia("C", "D");
        igual(dao.detectarCiclo(), List.of(), "Diamante compartido no es ciclo");
        igual(codigos(dao.consultarDependenciasIndirectas("A")), List.of("D"),
                "Compartida aparece una vez");
        igual(dao.calcularProfundidad("A"), 2, "Profundidad del diamante");
        dao.registrarDependencia("A", "D");
        igual(dao.consultarDependenciasIndirectas("A").size(), 0,
                "Una dependencia directa no se repite como indirecta");
        dao.registrarDependencia("D", "A");
        igual(dao.detectarCiclo(), List.of("A", "B", "D", "A"), "RF06 ciclo testigo cerrado");
        falla(IllegalStateException.class, () -> dao.calcularProfundidad("A"),
                "Profundidad cíclica no definida");
        igual(dao.calcularProfundidad("Z"), 0, "Ciclo desconectado no afecta a Z");
        igual(dao.consultarDependenciasIndirectas("A").size(), 0,
                "Consulta termina aun con ciclo y excluye raíz");
        exigir(dao.generarReporte().contains("A -> B -> D -> A"), "Reporte incluye ciclo");
        dao.registrarDependencia("Z", "Z");
        falla(IllegalStateException.class, () -> dao.calcularProfundidad("Z"), "Autociclo");
        igual(dao.consultarDependenciasIndirectas("Z").size(), 0, "Autociclo sin autorreferencia en resultado");
        exigir(codigos(dao.identificarTareasBloqueadas()).contains("Z"), "Autociclo pendiente bloqueado");
        DependenciasDAO aislado = new DependenciasDAO();
        aislado.registrarTarea("X", "Autociclo", Estado.COMPLETADA);
        aislado.registrarDependencia("X", "X");
        igual(aislado.detectarCiclo(), List.of("X", "X"), "Autociclo detectado aunque completado");
        igual(aislado.identificarTareasBloqueadas().size(), 0, "Completada no bloqueada aunque ciclo");
    }

    private static void probarVista() {
        DependenciasDAO dao = new DependenciasDAO();
        String salida = ejecutarVista("11\n3\nT06\n4\nT06\n5\nT06\n6\n7\n8\n10\n0\n", dao);
        exigir(salida.contains("Profundidad máxima (enlaces): 3"), "Vista calcula profundidad ejemplo");
        exigir(salida.contains("No existen ciclos en el grafo."), "Vista detecta sin ciclos");
        exigir(salida.contains("Programa finalizado."), "Vista termina por opción 0");
        igual(dao.consultarTareas().size(), 6, "Vista ejemplo con seis tareas");
        igual(codigos(dao.identificarTareasBloqueadas()), List.of("T04", "T05", "T06"),
                "Ejemplo empresarial coherente");
        String validacion = ejecutarVista("1\nX\nTarea X\n1\n9\nX\n2\n11\n99\n0\n", new DependenciasDAO());
        exigir(validacion.contains("Estado actualizado"), "Vista permite cambio de estado");
        exigir(validacion.contains("solo se carga en un proyecto vacío"), "Vista no sobrescribe ejemplo");
        exigir(validacion.contains("Opción inválida"), "Vista valida menú");
        String eof = ejecutarVista("1\n", new DependenciasDAO());
        exigir(eof.contains("Fin de la entrada"), "EOF durante captura termina limpiamente");
    }

    private static String ejecutarVista(String entrada, DependenciasDAO dao) {
        PrintStream anterior = System.out;
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (PrintStream captura = new PrintStream(bytes, true, StandardCharsets.UTF_8)) {
            System.setOut(captura);
            new DependenciasVista(new Scanner(entrada), dao).iniciar();
        } finally {
            System.setOut(anterior);
        }
        return bytes.toString(StandardCharsets.UTF_8);
    }

    private static List<String> codigos(List<TareaModelo> tareas) {
        return tareas.stream().map(TareaModelo::getCodigo).toList();
    }

    private static void igual(Object actual, Object esperado, String mensaje) {
        exigir(java.util.Objects.equals(actual, esperado), mensaje + ": " + actual + " != " + esperado);
    }

    private static void exigir(boolean condicion, String mensaje) {
        pruebas++;
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }

    private static void falla(Class<? extends Throwable> tipo, Runnable accion, String mensaje) {
        pruebas++;
        try {
            accion.run();
        } catch (Throwable error) {
            if (tipo.isInstance(error)) {
                return;
            }
            throw new AssertionError(mensaje + ": excepción inesperada " + error, error);
        }
        throw new AssertionError(mensaje + ": se esperaba " + tipo.getSimpleName());
    }
}
