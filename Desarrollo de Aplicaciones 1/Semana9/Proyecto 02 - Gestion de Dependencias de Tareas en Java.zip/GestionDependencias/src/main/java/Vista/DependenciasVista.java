package Vista;

import DAO.DependenciasDAO;
import Modelo.TareaModelo;
import Modelo.TareaModelo.Estado;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

/** Captura datos y presenta resultados; los recorridos recursivos están en el DAO. */
public final class DependenciasVista {
    private final Scanner teclado;
    private final DependenciasDAO dao;

    public DependenciasVista() {
        this(new Scanner(System.in, StandardCharsets.UTF_8), new DependenciasDAO());
    }

    public DependenciasVista(Scanner teclado, DependenciasDAO dao) {
        if (teclado == null || dao == null) {
            throw new IllegalArgumentException("Se requiere entrada y DAO.");
        }
        this.teclado = teclado;
        this.dao = dao;
    }

    public void iniciar() {
        System.out.println("GESTIÓN DE DEPENDENCIAS DE TAREAS - SEMANA 09");
        System.out.println("Cada enlace indica: tarea -> prerrequisito que necesita finalizar.");
        while (true) {
            try {
                mostrarMenu();
                String opcion = leer("Opción: ");
                switch (opcion) {
                    case "1" -> registrarTarea();
                    case "2" -> registrarDependencia();
                    case "3" -> mostrarTareas("Dependencias directas",
                            dao.consultarDependenciasDirectas(leer("Código de la tarea: ")));
                    case "4" -> mostrarIndirectas();
                    case "5" -> System.out.println("Profundidad máxima (enlaces): "
                            + dao.calcularProfundidad(leer("Código de la tarea: ")));
                    case "6" -> mostrarCiclo();
                    case "7" -> mostrarTareas("Tareas bloqueadas por prerrequisitos pendientes",
                            dao.identificarTareasBloqueadas());
                    case "8" -> System.out.print(dao.generarReporte());
                    case "9" -> cambiarEstado();
                    case "10" -> mostrarTareas("Tareas registradas", dao.consultarTareas());
                    case "11" -> cargarEjemplo();
                    case "0" -> {
                        System.out.println("Programa finalizado.");
                        return;
                    }
                    default -> System.out.println("Opción inválida. Seleccione una del menú.");
                }
            } catch (NoSuchElementException e) {
                System.out.println("\nFin de la entrada. Programa finalizado.");
                return;
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void mostrarMenu() {
        System.out.println("\n1. Registrar tarea (RF01)");
        System.out.println("2. Registrar dependencia (RF02)");
        System.out.println("3. Consultar dependencias directas (RF03)");
        System.out.println("4. Mostrar dependencias indirectas recursivamente (RF04)");
        System.out.println("5. Calcular profundidad máxima (RF05)");
        System.out.println("6. Detectar ciclos (RF06)");
        System.out.println("7. Identificar tareas bloqueadas (RF07)");
        System.out.println("8. Generar reporte (RF08)");
        System.out.println("9. Cambiar estado de una tarea");
        System.out.println("10. Listar tareas");
        System.out.println("11. Cargar ejemplo empresarial (solo con el proyecto vacío)");
        System.out.println("0. Salir");
    }

    private void registrarTarea() {
        String codigo = leer("Código único: ");
        String descripcion = leer("Descripción: ");
        Estado estado = leerEstado();
        System.out.println("Tarea registrada: " + dao.registrarTarea(codigo, descripcion, estado));
    }

    private void registrarDependencia() {
        String tarea = leer("Código de la tarea: ");
        String prerrequisito = leer("Código del prerrequisito: ");
        dao.registrarDependencia(tarea, prerrequisito);
        System.out.println("Dependencia registrada: " + tarea.trim().toUpperCase(java.util.Locale.ROOT)
                + " -> " + prerrequisito.trim().toUpperCase(java.util.Locale.ROOT));
        System.out.println("Use la opción 6 para comprobar si el grafo contiene ciclos.");
    }

    private void mostrarIndirectas() {
        String codigo = leer("Código de la tarea: ");
        mostrarTareas("Dependencias directas (separadas de las indirectas)",
                dao.consultarDependenciasDirectas(codigo));
        mostrarTareas("Dependencias indirectas (sin repetir directas ni la tarea consultada)",
                dao.consultarDependenciasIndirectas(codigo));
    }

    private void mostrarCiclo() {
        List<String> ciclo = dao.detectarCiclo();
        System.out.println(ciclo.isEmpty() ? "No existen ciclos en el grafo."
                : "Ciclo detectado: " + String.join(" -> ", ciclo));
    }

    private void cambiarEstado() {
        String codigo = leer("Código de la tarea: ");
        Estado nuevoEstado = leerEstado();
        dao.cambiarEstado(codigo, nuevoEstado);
        System.out.println("Estado actualizado. El bloqueo se recalcula al consultar el grafo.");
    }

    private Estado leerEstado() {
        String valor = leer("Estado (1 = pendiente, 2 = completada): ");
        return switch (valor) {
            case "1" -> Estado.PENDIENTE;
            case "2" -> Estado.COMPLETADA;
            default -> throw new IllegalArgumentException("El estado debe ser 1 o 2.");
        };
    }

    private void mostrarTareas(String titulo, List<TareaModelo> tareas) {
        System.out.println("--- " + titulo + " (" + tareas.size() + ") ---");
        if (tareas.isEmpty()) {
            System.out.println("Sin tareas para mostrar.");
        }
        for (TareaModelo tarea : tareas) {
            System.out.println(tarea);
        }
    }

    private void cargarEjemplo() {
        if (!dao.consultarTareas().isEmpty()) {
            throw new IllegalStateException("El ejemplo solo se carga en un proyecto vacío.");
        }
        dao.registrarTarea("T01", "Módulo de autenticación", Estado.COMPLETADA);
        dao.registrarTarea("T02", "Módulo de clientes", Estado.COMPLETADA);
        dao.registrarTarea("T03", "Módulo de inventario", Estado.PENDIENTE);
        dao.registrarTarea("T04", "Módulo de ventas", Estado.PENDIENTE);
        dao.registrarTarea("T05", "Módulo de reportes", Estado.PENDIENTE);
        dao.registrarTarea("T06", "Pruebas de integración", Estado.PENDIENTE);
        dao.registrarDependencia("T04", "T02");
        dao.registrarDependencia("T04", "T03");
        dao.registrarDependencia("T05", "T04");
        dao.registrarDependencia("T06", "T01");
        dao.registrarDependencia("T06", "T05");
        System.out.println("Ejemplo cargado: 6 tareas, 5 dependencias, sin ciclos.");
        System.out.println("T06 tiene profundidad 3 enlaces; T04, T05 y T06 están bloqueadas.");
    }

    private String leer(String mensaje) {
        System.out.print(mensaje);
        if (!teclado.hasNextLine()) {
            throw new NoSuchElementException("Fin de la entrada.");
        }
        return teclado.nextLine().trim();
    }
}
