package Vista;

/** Punto de entrada del proyecto GestionDependencias. */
public final class Principal {
    private Principal() { }

    public static void main(String[] args) {
        new DependenciasVista().iniciar();
    }
}
