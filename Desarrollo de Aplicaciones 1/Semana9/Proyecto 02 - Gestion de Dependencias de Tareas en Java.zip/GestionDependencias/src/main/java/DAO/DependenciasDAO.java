package DAO;

import Modelo.ProyectoModelo;
import Modelo.TareaModelo;
import Modelo.TareaModelo.Estado;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Operaciones RF01-RF08 sobre un grafo dirigido.
 * Los recorridos son recursividad estructural, tal como distingue el PDF:
 * recorrer hijos no equivale por sí mismo a la forma estricta f(f(...)).
 */
public final class DependenciasDAO {
    private final ProyectoModelo proyecto;

    public DependenciasDAO() { this(new ProyectoModelo()); }

    public DependenciasDAO(ProyectoModelo proyecto) {
        if (proyecto == null) {
            throw new IllegalArgumentException("El proyecto es obligatorio.");
        }
        this.proyecto = proyecto;
    }

    // RF01: códigos únicos; se conserva el orden de registro.
    public TareaModelo registrarTarea(String codigo, String descripcion, Estado estado) {
        TareaModelo tarea = new TareaModelo(codigo, descripcion, estado);
        proyecto.agregarTarea(tarea);
        return tarea;
    }

    // RF02: se permiten ciclos para que RF06 pueda identificarlos explícitamente.
    public void registrarDependencia(String tarea, String prerrequisito) {
        proyecto.agregarDependencia(tarea, prerrequisito);
    }

    public List<TareaModelo> consultarTareas() { return proyecto.getTareas(); }

    public void cambiarEstado(String codigo, Estado estado) {
        proyecto.cambiarEstado(codigo, estado);
    }

    // RF03: solo los vecinos inmediatos de la tarea.
    public List<TareaModelo> consultarDependenciasDirectas(String codigo) {
        return convertirTareas(proyecto.getDependencias(codigo));
    }

    // RF04: dependencias alcanzables que no están registradas como directas.
    public List<TareaModelo> consultarDependenciasIndirectas(String codigo) {
        String raiz = proyecto.obtenerTarea(codigo).getCodigo();
        Set<String> visitados = new HashSet<>();
        visitados.add(raiz); // La tarea consultada no debe aparecer como su propia dependencia.
        Set<String> resultado = new LinkedHashSet<>();
        recorrerDependencias(raiz, visitados, resultado);
        resultado.removeAll(proyecto.getDependencias(raiz));
        return convertirTareas(List.copyOf(resultado));
    }

    private void recorrerDependencias(String codigo, Set<String> visitados,
                                      Set<String> resultado) {
        for (String dependencia : proyecto.getDependencias(codigo)) {
            if (visitados.add(dependencia)) {
                resultado.add(dependencia);
                recorrerDependencias(dependencia, visitados, resultado);
            }
        }
        // Caso base implícito: sin hijos nuevos, el ciclo termina y retorna al padre.
    }

    // RF05: una tarea sin prerrequisitos tiene profundidad 0 enlaces.
    public int calcularProfundidad(String codigo) {
        String raiz = proyecto.obtenerTarea(codigo).getCodigo();
        return profundidad(raiz, new HashSet<>(), new HashMap<>());
    }

    private int profundidad(String codigo, Set<String> activos, Map<String, Integer> memoria) {
        if (memoria.containsKey(codigo)) {
            return memoria.get(codigo); // Subproblema ya resuelto, útil en un grafo con ramas compartidas.
        }
        if (!activos.add(codigo)) {
            throw new IllegalStateException(
                    "La profundidad no está definida: existe un ciclo alcanzable desde la tarea.");
        }
        int maxima = 0;
        for (String dependencia : proyecto.getDependencias(codigo)) {
            int profundidadHija = profundidad(dependencia, activos, memoria);
            maxima = Math.max(maxima, 1 + profundidadHija);
        }
        activos.remove(codigo);
        memoria.put(codigo, maxima);
        return maxima; // Caso base: sin dependencias, maxima permanece en 0.
    }

    // RF06: devuelve un ciclo testigo cerrado (A -> B -> A) o una lista vacía.
    public List<String> detectarCiclo() {
        Set<String> visitados = new HashSet<>();
        Set<String> activos = new HashSet<>();
        List<String> camino = new ArrayList<>();
        for (TareaModelo tarea : proyecto.getTareas()) {
            List<String> ciclo = buscarCiclo(tarea.getCodigo(), visitados, activos, camino);
            if (!ciclo.isEmpty()) {
                return ciclo;
            }
        }
        return List.of();
    }

    private List<String> buscarCiclo(String codigo, Set<String> visitados,
                                    Set<String> activos, List<String> camino) {
        if (activos.contains(codigo)) {
            int inicio = camino.indexOf(codigo);
            List<String> ciclo = new ArrayList<>(camino.subList(inicio, camino.size()));
            ciclo.add(codigo);
            return List.copyOf(ciclo);
        }
        if (!visitados.add(codigo)) {
            return List.of(); // Un nodo ya terminado no demuestra que haya un ciclo.
        }
        activos.add(codigo);
        camino.add(codigo);
        for (String dependencia : proyecto.getDependencias(codigo)) {
            List<String> ciclo = buscarCiclo(dependencia, visitados, activos, camino);
            if (!ciclo.isEmpty()) {
                return ciclo;
            }
        }
        camino.remove(camino.size() - 1);
        activos.remove(codigo);
        return List.of();
    }

    // RF07: una tarea pendiente está bloqueada si algún prerrequisito transitivo sigue pendiente.
    public List<TareaModelo> identificarTareasBloqueadas() {
        List<TareaModelo> bloqueadas = new ArrayList<>();
        for (TareaModelo tarea : proyecto.getTareas()) {
            if (!tarea.estaCompletada()
                    && tienePrerrequisitoPendiente(tarea.getCodigo(), new HashSet<>())) {
                bloqueadas.add(tarea);
            }
        }
        return List.copyOf(bloqueadas);
    }

    private boolean tienePrerrequisitoPendiente(String codigo, Set<String> visitados) {
        if (!visitados.add(codigo)) {
            return false; // No repetir una rama ya explorada en esta consulta.
        }
        for (String dependencia : proyecto.getDependencias(codigo)) {
            if (!proyecto.obtenerTarea(dependencia).estaCompletada()
                    || tienePrerrequisitoPendiente(dependencia, visitados)) {
                return true;
            }
        }
        return false; // Sin prerrequisitos pendientes: no está bloqueada por este motivo.
    }

    // RF08: bloqueadas es un subconjunto de pendientes; no se suma dos veces al total.
    public String generarReporte() {
        List<TareaModelo> todas = proyecto.getTareas();
        List<TareaModelo> pendientes = todas.stream().filter(t -> !t.estaCompletada()).toList();
        List<TareaModelo> completadas = todas.stream().filter(TareaModelo::estaCompletada).toList();
        List<TareaModelo> bloqueadas = identificarTareasBloqueadas();
        StringBuilder reporte = new StringBuilder("=== REPORTE DE TAREAS ===\n");
        reporte.append("Total: ").append(todas.size()).append('\n');
        agregarGrupo(reporte, "Pendientes", pendientes);
        agregarGrupo(reporte, "Completadas", completadas);
        agregarGrupo(reporte, "Bloqueadas (subconjunto de pendientes)", bloqueadas);
        List<String> ciclo = detectarCiclo();
        reporte.append("Ciclo detectado: ")
                .append(ciclo.isEmpty() ? "ninguno" : String.join(" -> ", ciclo)).append('\n');
        return reporte.toString();
    }

    private void agregarGrupo(StringBuilder salida, String titulo, List<TareaModelo> tareas) {
        salida.append(titulo).append(": ").append(tareas.size()).append('\n');
        for (TareaModelo tarea : tareas) {
            salida.append("  ").append(tarea).append('\n');
        }
    }

    private List<TareaModelo> convertirTareas(List<String> codigos) {
        List<TareaModelo> resultado = new ArrayList<>();
        for (String codigo : codigos) {
            resultado.add(proyecto.obtenerTarea(codigo));
        }
        return List.copyOf(resultado);
    }
}
