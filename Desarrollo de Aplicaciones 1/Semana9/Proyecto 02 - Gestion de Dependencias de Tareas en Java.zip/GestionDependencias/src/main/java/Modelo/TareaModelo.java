package Modelo;

import java.util.Locale;

/** Datos de una tarea. El bloqueo se calcula a partir del grafo, no es un estado guardado. */
public final class TareaModelo {
    public enum Estado { PENDIENTE, COMPLETADA }

    private final String codigo;
    private final String descripcion;
    private final Estado estado;

    public TareaModelo(String codigo, String descripcion, Estado estado) {
        this.codigo = normalizarCodigo(codigo);
        if (descripcion == null || descripcion.isBlank()) {
            throw new IllegalArgumentException("La descripción es obligatoria.");
        }
        if (estado == null) {
            throw new IllegalArgumentException("El estado es obligatorio.");
        }
        this.descripcion = descripcion.trim();
        this.estado = estado;
    }

    public static String normalizarCodigo(String codigo) {
        if (codigo == null || codigo.isBlank()) {
            throw new IllegalArgumentException("El código es obligatorio.");
        }
        return codigo.trim().toUpperCase(Locale.ROOT);
    }

    public String getCodigo() { return codigo; }
    public String getDescripcion() { return descripcion; }
    public Estado getEstado() { return estado; }
    public boolean estaCompletada() { return estado == Estado.COMPLETADA; }

    public TareaModelo conEstado(Estado nuevoEstado) {
        return new TareaModelo(codigo, descripcion, nuevoEstado);
    }

    @Override
    public String toString() {
        return codigo + " | " + descripcion + " | " + estado;
    }
}
