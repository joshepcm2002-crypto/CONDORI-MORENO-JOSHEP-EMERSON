package Modelo;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/** Almacena las tareas y las aristas tarea -> prerrequisito en memoria. */
public final class ProyectoModelo {
    private final Map<String, TareaModelo> tareas = new LinkedHashMap<>();
    private final Map<String, LinkedHashSet<String>> dependencias = new LinkedHashMap<>();

    public void agregarTarea(TareaModelo tarea) {
        if (tarea == null) {
            throw new IllegalArgumentException("La tarea es obligatoria.");
        }
        if (tareas.containsKey(tarea.getCodigo())) {
            throw new IllegalArgumentException("Ya existe una tarea con ese código.");
        }
        tareas.put(tarea.getCodigo(), tarea);
        dependencias.put(tarea.getCodigo(), new LinkedHashSet<>());
    }

    public TareaModelo obtenerTarea(String codigo) {
        TareaModelo tarea = tareas.get(TareaModelo.normalizarCodigo(codigo));
        if (tarea == null) {
            throw new IllegalArgumentException("No existe la tarea indicada.");
        }
        return tarea;
    }

    public List<TareaModelo> getTareas() {
        return List.copyOf(tareas.values());
    }

    public List<String> getDependencias(String codigo) {
        String clave = obtenerTarea(codigo).getCodigo();
        return List.copyOf(dependencias.get(clave));
    }

    public void agregarDependencia(String codigoTarea, String codigoPrerrequisito) {
        String tarea = obtenerTarea(codigoTarea).getCodigo();
        String prerrequisito = obtenerTarea(codigoPrerrequisito).getCodigo();
        if (!dependencias.get(tarea).add(prerrequisito)) {
            throw new IllegalArgumentException("La dependencia ya está registrada.");
        }
    }

    public void cambiarEstado(String codigo, TareaModelo.Estado estado) {
        TareaModelo actual = obtenerTarea(codigo);
        tareas.put(actual.getCodigo(), actual.conEstado(estado));
    }
}
