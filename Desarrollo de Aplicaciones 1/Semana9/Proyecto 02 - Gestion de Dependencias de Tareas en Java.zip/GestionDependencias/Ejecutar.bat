@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0"
if not exist "target\GestionDependencias.jar" (
    call Compilar.bat --sin-pausa
    if errorlevel 1 goto error
)
set "PROYECTO_JAVA=java"
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\java.exe" set "PROYECTO_JAVA=%JAVA_HOME%\bin\java.exe"
)
"%PROYECTO_JAVA%" -Dfile.encoding=UTF-8 -jar "target\GestionDependencias.jar"
set "PROYECTO_RESULTADO=%ERRORLEVEL%"
if not "%PROYECTO_RESULTADO%"=="0" echo Se necesita Java 17 o superior para ejecutar este programa.
popd
if /I not "%~1"=="--sin-pausa" pause
exit /b %PROYECTO_RESULTADO%
:error
popd
if /I not "%~1"=="--sin-pausa" pause
exit /b 1
