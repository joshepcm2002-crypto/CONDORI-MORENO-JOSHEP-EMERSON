@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0"
call Compilar.bat --sin-pausa
if errorlevel 1 goto error
set "PROYECTO_JAVAC=javac"
set "PROYECTO_JAVA=java"
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\javac.exe" set "PROYECTO_JAVAC=%JAVA_HOME%\bin\javac.exe"
    if exist "%JAVA_HOME%\bin\java.exe" set "PROYECTO_JAVA=%JAVA_HOME%\bin\java.exe"
)
if not exist "target\test-classes" mkdir "target\test-classes"
"%PROYECTO_JAVAC%" --release 17 -encoding UTF-8 -Xlint:all -classpath "target\classes" -sourcepath "src\test\java" -d "target\test-classes" "src\test\java\Pruebas\PruebasDependencias.java"
if errorlevel 1 goto error
"%PROYECTO_JAVA%" -Dfile.encoding=UTF-8 -classpath "target\classes;target\test-classes" Pruebas.PruebasDependencias
if errorlevel 1 goto error
popd
if /I not "%~1"=="--sin-pausa" pause
exit /b 0
:error
popd
if /I not "%~1"=="--sin-pausa" pause
exit /b 1
