package Pruebas;

import DAO.AckermannDAO;
import Modelo.AckermannModelo;

public final class PruebasAckermann {
    private static int pruebas;

    private static void igual(long esperado, long real) {
        pruebas++;
        if (esperado != real) throw new AssertionError(esperado + " != " + real);
    }

    private static void rechaza(Runnable operacion) {
        pruebas++;
        try {
            operacion.run();
        } catch (IllegalArgumentException e) {
            return;
        }
        throw new AssertionError("Debia rechazar la entrada.");
    }

    public static void main(String[] args) {
        AckermannDAO dao = new AckermannDAO();
        // Valores cerrados como oráculo independiente; el DAO sigue siendo recursivo.
        for (int n = 0; n <= 6; n++) {
            igual(n + 1L, dao.calcular(0, n));
            igual(n + 2L, dao.calcular(1, n));
            igual(2L * n + 3, dao.calcular(2, n));
            igual((1L << (n + 3)) - 3, dao.calcular(3, n));
        }
        rechaza(() -> dao.calcular(-1, 0));
        rechaza(() -> dao.calcular(0, -1));
        rechaza(() -> dao.calcular(4, 0));
        rechaza(() -> dao.calcular(0, 7));
        rechaza(() -> dao.calcular(Integer.MAX_VALUE, Integer.MAX_VALUE));
        rechaza(() -> new AckermannModelo(-1, 0));
        rechaza(() -> new AckermannModelo(0, -1));
        AckermannModelo modelo = new AckermannModelo(1, 3);
        igual(1, modelo.getM());
        igual(3, modelo.getN());
        modelo.setResultado(dao.calcular(modelo.getM(), modelo.getN()));
        igual(5, modelo.getResultado());
        System.out.println("ACKERMANN: " + pruebas + " comprobaciones superadas.");
    }
}
