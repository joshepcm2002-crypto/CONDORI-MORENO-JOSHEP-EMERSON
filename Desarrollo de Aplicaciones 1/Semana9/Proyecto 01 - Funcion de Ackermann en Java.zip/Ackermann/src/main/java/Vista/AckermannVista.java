package Vista;

import DAO.AckermannDAO;
import Modelo.AckermannModelo;
import java.util.Scanner;

public final class AckermannVista {
    private final Scanner teclado = new Scanner(System.in);
    private final AckermannDAO dao = new AckermannDAO();

    public void iniciar() {
        System.out.println("SEMANA 09 - FUNCION DE ACKERMANN");
        System.out.println("Limite didactico del material: 0 <= m <= 3; 0 <= n <= 6.");
        try {
            System.out.print("Ingrese m (0 a 3): ");
            if (!teclado.hasNextLine()) return;
            int m = Integer.parseInt(teclado.nextLine().trim());
            System.out.print("Ingrese n (0 a 6): ");
            if (!teclado.hasNextLine()) return;
            int n = Integer.parseInt(teclado.nextLine().trim());
            AckermannModelo modelo = new AckermannModelo(m, n);
            long resultado = dao.calcular(modelo.getM(), modelo.getN());
            modelo.setResultado(resultado);
            System.out.println("\n--- RESULTADO ---");
            System.out.println("m = " + modelo.getM());
            System.out.println("n = " + modelo.getN());
            System.out.println("Ackermann = " + modelo.getResultado());
        } catch (NumberFormatException e) {
            System.out.println("Error: debe ingresar numeros enteros.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (StackOverflowError e) {
            // Protección didáctica indicada por el PDF; no se reintenta el cálculo.
            System.out.println("El calculo excedio la capacidad de la pila.");
        }
    }
}
