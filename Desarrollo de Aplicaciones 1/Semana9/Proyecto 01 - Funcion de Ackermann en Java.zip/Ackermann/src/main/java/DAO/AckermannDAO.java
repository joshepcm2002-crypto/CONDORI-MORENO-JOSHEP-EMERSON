package DAO;

/** Conserva los tres casos y el límite didáctico del código del ingeniero. */
public final class AckermannDAO {
    // Método de inicio: valida; el auxiliar ackermann realiza la recursión.
    public long calcular(int m, int n) {
        if (m < 0 || n < 0) {
            throw new IllegalArgumentException("Los parametros deben ser no negativos.");
        }
        if (m > 3 || n > 6) {
            throw new IllegalArgumentException("Entrada fuera del limite didactico.");
        }
        return ackermann(m, n);
    }

    private long ackermann(int m, int n) {
        // Caso base: devuelve un resultado sin otra llamada.
        if (m == 0) {
            return n + 1L;
        }
        // Caso recursivo con n igual a cero.
        if (n == 0) {
            return ackermann(m - 1, 1);
        }
        // Recursividad anidada estricta: primero se resuelve la llamada interior.
        // Su resultado pasa a ser el segundo argumento de la llamada exterior.
        // La conversión es válida dentro del dominio limitado por calcular().
        return ackermann(m - 1, (int) ackermann(m, n - 1));
    }
}
