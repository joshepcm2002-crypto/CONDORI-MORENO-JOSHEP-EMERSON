package Modelo;

/** Parámetros y resultado, según el modelo del material de la Semana 09. */
public final class AckermannModelo {
    private final int m;
    private final int n;
    private long resultado;

    public AckermannModelo(int m, int n) {
        if (m < 0 || n < 0) {
            throw new IllegalArgumentException("Los parametros deben ser no negativos.");
        }
        this.m = m;
        this.n = n;
    }

    public int getM() { return m; }
    public int getN() { return n; }
    public long getResultado() { return resultado; }
    public void setResultado(long resultado) { this.resultado = resultado; }
}
