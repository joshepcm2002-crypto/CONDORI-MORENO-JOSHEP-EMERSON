@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0"
set "PROYECTO_JAVAC=javac"
set "PROYECTO_JAR=jar"
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\javac.exe" set "PROYECTO_JAVAC=%JAVA_HOME%\bin\javac.exe"
    if exist "%JAVA_HOME%\bin\jar.exe" set "PROYECTO_JAR=%JAVA_HOME%\bin\jar.exe"
)
if not exist "target\classes" mkdir "target\classes"
"%PROYECTO_JAVAC%" --release 17 -encoding UTF-8 -Xlint:all -sourcepath "src\main\java" -d "target\classes" "src\main\java\Vista\Principal.java"
if errorlevel 1 goto error
"%PROYECTO_JAR%" "-J-Djava.io.tmpdir=%CD%\target" --create --file "target\EvaluadorReglasComerciales.jar" --main-class Vista.Principal -C "target\classes" .
if errorlevel 1 goto error
echo Compilacion completada. Puede abrir Ejecutar.bat.
popd
if /I not "%~1"=="--sin-pausa" pause
exit /b 0
:error
echo No se pudo compilar. Se necesita un JDK 17 o superior.
popd
if /I not "%~1"=="--sin-pausa" pause
exit /b 1
