package DAO;

import Modelo.ExpresionModelo;
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.List;

/**
 * Analizador recursivo descendente propuesto en el material del ingeniero.
 * expresion = termino { ('+' | '-') termino }
 * termino   = factor  { ('*' | '/') factor }
 * factor    = numero | '(' expresion ')' | ('+' | '-') factor
 * La recursividad indirecta aparece en factor -> expresion -> termino -> factor.
 * Procesa parentesis anidados; no es la forma matematica estricta f(f(x)).
 */
public final class EvaluadorExpresionesDAO {
    public static final int MAX_LONGITUD = 2000;
    public static final int MAX_ANIDAMIENTO = 100;
    public static final MathContext PRECISION_DIVISION = MathContext.DECIMAL128;
    private final List<ExpresionModelo> historial = new ArrayList<>();

    /** RF01..09: acepta una evaluacion solo si toda la expresion es valida. */
    public ExpresionModelo evaluar(String expresion) {
        BigDecimal resultado = validar(expresion);
        ExpresionModelo evaluacion = new ExpresionModelo(expresion, resultado);
        historial.add(evaluacion);
        return evaluacion;
    }

    /** RF10: verifica sintaxis y operaciones antes de aceptar la expresion. */
    public BigDecimal validar(String expresion) {
        if (expresion == null || expresion.isBlank()) {
            throw new IllegalArgumentException("La expresion no puede estar vacia.");
        }
        if (expresion.length() > MAX_LONGITUD) {
            throw new IllegalArgumentException("La expresion supera " + MAX_LONGITUD + " caracteres.");
        }
        // Inicio no recursivo. Cada analisis tiene su propio cursor y profundidad.
        return new Analizador(expresion).analizar();
    }

    public List<ExpresionModelo> getHistorial() {
        return List.copyOf(historial);
    }

    private static final class Analizador {
        private final String texto;
        private int posicion;
        private int profundidad;

        private Analizador(String texto) {
            this.texto = texto;
        }

        private BigDecimal analizar() {
            BigDecimal resultado = expresion();
            omitirEspacios();
            if (posicion != texto.length()) {
                throw error("Simbolo inesperado '" + texto.charAt(posicion) + "'");
            }
            return resultado;
        }

        /** Nivel de menor precedencia. Los operadores iguales se asocian a la izquierda. */
        private BigDecimal expresion() {
            BigDecimal resultado = termino();
            while (true) {
                if (consumir('+')) {
                    resultado = resultado.add(termino());
                } else if (consumir('-')) {
                    resultado = resultado.subtract(termino());
                } else {
                    return resultado;
                }
            }
        }

        /** Nivel de mayor precedencia; una division valida nunca acepta divisor cero. */
        private BigDecimal termino() {
            BigDecimal resultado = factor();
            while (true) {
                if (consumir('*')) {
                    resultado = resultado.multiply(factor());
                } else if (consumir('/')) {
                    BigDecimal divisor = factor();
                    if (divisor.signum() == 0) {
                        throw error("No se permite dividir por cero");
                    }
                    // Politica explicita: 34 cifras significativas, HALF_EVEN.
                    resultado = resultado.divide(divisor, PRECISION_DIVISION);
                } else {
                    return resultado;
                }
            }
        }

        private BigDecimal factor() {
            omitirEspacios();
            // El numero final no cuenta como un nivel adicional de parentesis o signo.
            if (profundidad++ > MAX_ANIDAMIENTO) {
                throw error("Se supera el limite de " + MAX_ANIDAMIENTO + " niveles anidados");
            }
            try {
                if (consumir('+')) {
                    return factor();
                }
                if (consumir('-')) {
                    return factor().negate();
                }
                if (consumir('(')) {
                    // Recursion indirecta: resolver el interior antes de continuar afuera.
                    BigDecimal resultado = expresion();
                    if (!consumir(')')) {
                        throw error("Falta cerrar un parentesis con ')'");
                    }
                    return resultado;
                }
                // Caso base: un numero no necesita nuevas llamadas recursivas.
                return numero();
            } finally {
                // Al retornar se recupera el nivel de la expresion que esperaba.
                profundidad--;
            }
        }

        private BigDecimal numero() {
            omitirEspacios();
            int inicio = posicion;
            while (posicion < texto.length() && esDigito(texto.charAt(posicion))) {
                posicion++;
            }
            boolean tieneDigitos = posicion > inicio;
            if (posicion < texto.length() && texto.charAt(posicion) == '.') {
                posicion++;
                int inicioDecimales = posicion;
                while (posicion < texto.length() && esDigito(texto.charAt(posicion))) {
                    posicion++;
                }
                tieneDigitos |= posicion > inicioDecimales;
            }
            if (!tieneDigitos) {
                throw error("Se esperaba un numero o un parentesis de apertura");
            }
            return new BigDecimal(texto.substring(inicio, posicion));
        }

        private boolean esDigito(char caracter) {
            return caracter >= '0' && caracter <= '9';
        }

        private boolean consumir(char simbolo) {
            omitirEspacios();
            if (posicion < texto.length() && texto.charAt(posicion) == simbolo) {
                posicion++;
                return true;
            }
            return false;
        }

        private void omitirEspacios() {
            while (posicion < texto.length() && Character.isWhitespace(texto.charAt(posicion))) {
                posicion++;
            }
        }

        private IllegalArgumentException error(String mensaje) {
            return new IllegalArgumentException(mensaje + " (posicion " + (posicion + 1) + ").");
        }
    }
}
