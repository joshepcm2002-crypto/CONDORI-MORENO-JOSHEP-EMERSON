package Vista;

/** Punto de entrada del proyecto. */
public final class Principal {
    private Principal() {
    }

    public static void main(String[] args) {
        new EvaluadorExpresionesVista().iniciar();
    }
}
