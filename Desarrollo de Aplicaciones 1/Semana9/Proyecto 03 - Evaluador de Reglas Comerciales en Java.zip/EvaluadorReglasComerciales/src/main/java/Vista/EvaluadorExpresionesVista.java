package Vista;

import DAO.EvaluadorExpresionesDAO;
import Modelo.ExpresionModelo;
import java.math.BigDecimal;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

/** Captura expresiones y muestra los resultados; el analisis pertenece al DAO. */
public final class EvaluadorExpresionesVista {
    private final Scanner teclado;
    private final EvaluadorExpresionesDAO dao;

    public EvaluadorExpresionesVista() {
        this(new Scanner(System.in), new EvaluadorExpresionesDAO());
    }

    public EvaluadorExpresionesVista(Scanner teclado, EvaluadorExpresionesDAO dao) {
        if (teclado == null || dao == null) {
            throw new IllegalArgumentException("La vista requiere teclado y DAO.");
        }
        this.teclado = teclado;
        this.dao = dao;
    }

    public void iniciar() {
        System.out.println("EVALUADOR DE FORMULAS Y REGLAS COMERCIALES");
        System.out.println("Numeros decimales con punto; operadores +, -, *, / y parentesis.");
        System.out.println("Sumas, restas y productos exactos. Division: DECIMAL128 (34 cifras significativas).");
        System.out.println("Limites: " + EvaluadorExpresionesDAO.MAX_LONGITUD + " caracteres y "
                + EvaluadorExpresionesDAO.MAX_ANIDAMIENTO + " niveles (parentesis y signos unarios).");
        try {
            while (true) {
                System.out.println("\n1. Evaluar y guardar resultado");
                System.out.println("2. Validar expresion sin guardar");
                System.out.println("3. Mostrar evaluaciones de la sesion");
                System.out.println("0. Salir");
                System.out.print("Opcion: ");
                String opcion = teclado.nextLine().trim();
                if (opcion.equals("0")) {
                    return;
                }
                try {
                    switch (opcion) {
                        case "1" -> evaluar();
                        case "2" -> validar();
                        case "3" -> mostrarHistorial();
                        default -> System.out.println("Seleccione una opcion del menu.");
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        } catch (NoSuchElementException e) {
            // El fin de entrada tambien termina la aplicacion, sin repetir el menu.
        }
    }

    private void evaluar() {
        System.out.print("Expresion: ");
        ExpresionModelo evaluacion = dao.evaluar(teclado.nextLine());
        System.out.println("Expresion original: " + evaluacion.getExpresion());
        System.out.println("Resultado: " + formato(evaluacion.getResultado()));
        System.out.println("Evaluacion validada y guardada en la sesion.");
    }

    private void validar() {
        System.out.print("Expresion: ");
        String expresion = teclado.nextLine();
        BigDecimal resultado = dao.validar(expresion);
        System.out.println("Expresion valida: " + expresion);
        System.out.println("Resultado: " + formato(resultado));
        System.out.println("No se agrego al historial.");
    }

    private void mostrarHistorial() {
        List<ExpresionModelo> historial = dao.getHistorial();
        if (historial.isEmpty()) {
            System.out.println("Aun no hay evaluaciones guardadas.");
            return;
        }
        for (int i = 0; i < historial.size(); i++) {
            System.out.println((i + 1) + ". " + historial.get(i));
        }
    }

    private String formato(BigDecimal numero) {
        return numero.stripTrailingZeros().toPlainString();
    }
}
