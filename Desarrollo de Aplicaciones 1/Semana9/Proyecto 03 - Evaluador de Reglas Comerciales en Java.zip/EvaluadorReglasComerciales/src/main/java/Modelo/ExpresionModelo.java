package Modelo;

import java.math.BigDecimal;

/** Expresion original y resultado de una evaluacion que termino correctamente. */
public final class ExpresionModelo {
    private final String expresion;
    private final BigDecimal resultado;

    public ExpresionModelo(String expresion, BigDecimal resultado) {
        if (expresion == null || expresion.isBlank()) {
            throw new IllegalArgumentException("La expresion no puede estar vacia.");
        }
        if (resultado == null) {
            throw new IllegalArgumentException("El resultado no puede ser null.");
        }
        this.expresion = expresion;
        this.resultado = resultado;
    }

    public String getExpresion() {
        return expresion;
    }

    public BigDecimal getResultado() {
        return resultado;
    }

    @Override
    public String toString() {
        return expresion + " = " + resultado.stripTrailingZeros().toPlainString();
    }
}
