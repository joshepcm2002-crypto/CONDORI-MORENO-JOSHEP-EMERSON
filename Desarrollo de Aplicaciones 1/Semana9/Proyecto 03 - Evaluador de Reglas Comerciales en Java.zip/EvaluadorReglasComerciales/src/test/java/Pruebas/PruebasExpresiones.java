package Pruebas;

import DAO.EvaluadorExpresionesDAO;
import Modelo.ExpresionModelo;
import Vista.EvaluadorExpresionesVista;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/** Pruebas ejecutables sin bibliotecas externas. */
public final class PruebasExpresiones {
    private static int comprobaciones;

    private PruebasExpresiones() {
    }

    public static void main(String[] args) {
        EvaluadorExpresionesDAO dao = new EvaluadorExpresionesDAO();
        igual("7", dao.validar("1 + 2 * 3"));
        igual("9", dao.validar("(1 + 2) * 3"));
        igual("1062", dao.validar("(1000 - 100) * (1 + 0.18)"));
        igual("21", dao.validar("((1+2)*(3+(8/2)))"));
        igual("5", dao.validar("10 - 3 - 2"));
        igual("2", dao.validar("20 / 5 / 2"));
        igual("1", dao.validar("8 / (2 * (1 + 3))"));
        igual("-6", dao.validar("-(1 + 2) * +2"));
        igual("5", dao.validar("3--2"));
        igual("2", dao.validar("--2"));
        igual("0.3", dao.validar("0.1 + 0.2"));
        igual("0.02", dao.validar("0.1 * 0.2"));
        igual("1.25", dao.validar(".5 + .75"));
        igual("2", dao.validar("2."));
        igual("0.125", dao.validar("1/8"));
        igual("0.3333333333333333333333333333333333", dao.validar("1/3"));
        igual("99999999999999999999999999999999999999", dao.validar("99999999999999999999999999999999999998+1"));
        igual("-12.5", dao.validar(" \t - 12.5 \n"));

        String[] invalidas = {null, "", " \t", "()", "(1+2", "1+2)", "1+", "*2", "1**2",
            "2(3+4)", "1 2", "1..2", ".", "NaN", "Infinity", "1e3", "3%2", "[2]", "2,5", "abc", "2+)3("};
        for (String expresion : invalidas) {
            rechaza(() -> dao.evaluar(expresion), "expresion invalida: " + expresion);
        }
        rechaza(() -> dao.evaluar("1/0"), "cero literal");
        rechaza(() -> dao.evaluar("5/(3-3)"), "cero calculado");
        rechaza(() -> dao.evaluar("5/-0.000"), "cero negativo");
        comprueba(dao.getHistorial().isEmpty(), "Validar o fallar no registra evaluaciones");

        String original = "  (100 - 10) * 1.18  ";
        ExpresionModelo modelo = dao.evaluar(original);
        comprueba(modelo.getExpresion().equals(original), "Se conserva la expresion original exacta");
        igual("106.2", modelo.getResultado());
        dao.evaluar("2+2");
        comprueba(dao.getHistorial().size() == 2, "Varias evaluaciones en una sesion");
        rechaza(() -> dao.evaluar("(7"), "error posterior a un exito");
        comprueba(dao.getHistorial().size() == 2, "Un error no cambia el historial previo");
        igual("8", dao.evaluar("2*(3+1)").getResultado());
        comprueba(dao.getHistorial().size() == 3, "Un analisis fallido no contamina el siguiente");
        boolean protegida = false;
        try {
            dao.getHistorial().clear();
        } catch (UnsupportedOperationException e) {
            protegida = true;
        }
        comprueba(protegida && dao.getHistorial().size() == 3, "Historial expuesto como copia inmodificable");
        rechaza(() -> new ExpresionModelo("", BigDecimal.ONE), "modelo vacio");
        rechaza(() -> new ExpresionModelo("1", null), "modelo sin resultado");
        igual("1", dao.validar("(".repeat(100) + "1" + ")".repeat(100)));
        rechaza(() -> dao.validar("(".repeat(101) + "1" + ")".repeat(101)), "limite de anidamiento");
        rechaza(() -> dao.validar("1".repeat(EvaluadorExpresionesDAO.MAX_LONGITUD + 1)), "limite de longitud");
        igual("2", dao.validar("1+1"));
        pruebaVista();
        System.out.println("Pruebas de expresiones superadas: " + comprobaciones);
    }

    private static void pruebaVista() {
        String entrada = "1\n(10-2)*3\n1\n1/0\n1\n0.1+0.2\n2\n(3+1)\n3\n0\n";
        EvaluadorExpresionesDAO dao = new EvaluadorExpresionesDAO();
        ByteArrayOutputStream captura = new ByteArrayOutputStream();
        PrintStream anterior = System.out;
        try (PrintStream salida = new PrintStream(captura, true, StandardCharsets.UTF_8)) {
            System.setOut(salida);
            new EvaluadorExpresionesVista(new Scanner(entrada), dao).iniciar();
            new EvaluadorExpresionesVista(new Scanner("1\n"), dao).iniciar();
        } finally {
            System.setOut(anterior);
        }
        String texto = captura.toString(StandardCharsets.UTF_8);
        comprueba(texto.contains("Expresion original: (10-2)*3"), "La vista muestra la expresion");
        comprueba(texto.contains("Resultado: 24"), "La vista muestra el resultado");
        comprueba(texto.contains("dividir por cero"), "La vista informa una division por cero");
        comprueba(texto.contains("Resultado: 0.3"), "La vista continua despues del error");
        comprueba(texto.contains("Expresion valida: (3+1)"), "Validacion previa disponible");
        comprueba(dao.getHistorial().size() == 2, "La vista registra solo las evaluaciones correctas");
    }

    private static void igual(String esperado, BigDecimal actual) {
        comprueba(new BigDecimal(esperado).compareTo(actual) == 0,
                "Se esperaba " + esperado + " y se obtuvo " + actual);
    }

    private static void rechaza(Runnable operacion, String descripcion) {
        boolean rechazo = false;
        try {
            operacion.run();
        } catch (IllegalArgumentException e) {
            rechazo = true;
        }
        comprueba(rechazo, "Debe rechazarse: " + descripcion);
    }

    private static void comprueba(boolean condicion, String descripcion) {
        if (!condicion) {
            throw new AssertionError(descripcion);
        }
        comprobaciones++;
    }
}
