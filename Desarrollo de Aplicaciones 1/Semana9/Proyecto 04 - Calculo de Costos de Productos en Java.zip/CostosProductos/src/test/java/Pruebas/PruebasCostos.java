package Pruebas;

import DAO.CostosProductosDAO;
import Modelo.ComponenteModelo;
import Modelo.ProductoModelo;
import Vista.CostosProductosVista;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Scanner;

/** Pruebas funcionales autoejecutables, sin bibliotecas externas. */
public final class PruebasCostos {
    private static int comprobaciones;
    private PruebasCostos() { }

    public static void main(String[] args) {
        CostosProductosDAO dao = new CostosProductosDAO();
        igual(0, dao.listarProductos().size());
        igual(List.of(), dao.detectarCiclos());
        igual(0, dao.identificarComponentesCompartidos().size());
        falla(IllegalArgumentException.class, () -> dao.buscarProducto("NO"));
        falla(IllegalArgumentException.class, () -> dao.registrarComponente(null, "x", d("1")));
        falla(IllegalArgumentException.class, () -> dao.registrarProducto(" ", "x"));
        falla(IllegalArgumentException.class, () -> dao.registrarProducto("X", " "));
        falla(IllegalArgumentException.class, () -> dao.registrarComponente("X", "x", d("-1")));
        falla(IllegalArgumentException.class, () -> dao.registrarComponente("X", "x", null));
        igual(0, dao.listarProductos().size());

        dao.registrarComponente(" c ", "Pieza", d("0.1"));
        igual("C", dao.buscarProducto("c").getCodigo());
        numero("0.1", dao.calcularCostoTotal("C"));
        falla(IllegalArgumentException.class, () -> dao.registrarProducto("c", "duplicado"));
        dao.registrarProducto("P", "Producto");
        numero("0", dao.calcularCostoTotal("P"));
        verdad(dao.buscarProducto("P").esCompuesto());
        falla(IllegalArgumentException.class, () -> dao.registrarCostoUnitario("P", d("100")));
        falla(IllegalArgumentException.class, () -> dao.agregarComponente("C", "P", d("1")));
        falla(IllegalArgumentException.class, () -> dao.agregarComponente("P", "NO", d("1")));
        falla(IllegalArgumentException.class, () -> dao.agregarComponente("P", "C", d("-1")));
        falla(IllegalArgumentException.class, () -> dao.agregarComponente("P", "C", null));
        igual(0, dao.buscarProducto("P").getComponentes().size());
        dao.agregarComponente("P", "C", d("3"));
        numero("0.3", dao.calcularCostoTotal("P"));
        falla(IllegalArgumentException.class, () -> dao.agregarComponente("P", "C", d("1")));
        igual(1, dao.buscarProducto("P").getComponentes().size());
        falla(UnsupportedOperationException.class, () -> dao.listarProductos().clear());
        falla(UnsupportedOperationException.class, () -> dao.buscarProducto("P").getComponentes().clear());
        falla(IllegalArgumentException.class, () -> dao.registrarCostoUnitario("C", d("-2")));
        numero("0.3", dao.calcularCostoTotal("P"));
        dao.registrarCostoUnitario("C", d("0.2"));
        numero("0.6", dao.calcularCostoTotal("P"));
        dao.actualizarCantidad("P", "C", d("2.5"));
        numero("0.5", dao.calcularCostoTotal("P"));
        falla(IllegalArgumentException.class, () -> dao.actualizarCantidad("P", "C", d("-1")));
        numero("0.5", dao.calcularCostoTotal("P"));

        // Diamante: una misma pieza se usa en dos ramas; no es un ciclo y aporta dos veces.
        dao.registrarProducto("Q", "Segundo producto");
        dao.registrarProducto("R", "Raíz");
        dao.agregarComponente("Q", "C", d("4"));
        dao.agregarComponente("R", "P", d("2"));
        dao.agregarComponente("R", "Q", d("3"));
        numero("3.4", dao.calcularCostoTotal("R"));
        igual(List.of(), dao.detectarCiclos());
        igual(List.of("P", "Q", "R"), dao.identificarComponentesCompartidos().get("C"));
        falla(UnsupportedOperationException.class, () -> dao.identificarComponentesCompartidos().clear());
        falla(UnsupportedOperationException.class, () -> dao.identificarComponentesCompartidos().get("C").clear());
        String desglose = dao.mostrarDesglose("R");
        verdad(desglose.contains("2 |     C | 5 | 0.2 | 1"));
        verdad(desglose.contains("2 |     C | 12 | 0.2 | 2.4"));
        String reporte = dao.generarReporteFabricacion("R", d("10"));
        verdad(reporte.contains("Costo por unidad: 3.4"));
        verdad(reporte.contains("Costo estimado total: 34"));
        verdad(dao.generarReporteFabricacion("R", d("0")).contains("Costo estimado total: 0\n"));
        falla(IllegalArgumentException.class, () -> dao.generarReporteFabricacion("R", d("-1")));
        falla(IllegalArgumentException.class, () -> dao.generarReporteFabricacion("R", null));
        falla(IllegalArgumentException.class, () -> dao.actualizarCantidad("Q", "P", d("1")));
        dao.actualizarCantidad("Q", "C", BigDecimal.ZERO);
        numero("1", dao.calcularCostoTotal("R"));

        // Ciclo desconectado: se detecta globalmente, sin impedir un costo de otra composición válida.
        dao.registrarProducto("X", "Cíclico X");
        dao.registrarProducto("Y", "Cíclico Y");
        dao.agregarComponente("X", "Y", d("1"));
        dao.agregarComponente("Y", "X", d("0"));
        igual(List.of("X -> Y -> X"), dao.detectarCiclos());
        numero("1", dao.calcularCostoTotal("R"));
        falla(IllegalStateException.class, () -> dao.calcularCostoTotal("X"));
        falla(IllegalStateException.class, () -> dao.mostrarDesglose("X"));
        falla(IllegalStateException.class, () -> dao.generarReporteFabricacion("X", d("1")));
        verdad(dao.identificarComponentesCompartidos().containsKey("C"));
        dao.registrarProducto("AUTO", "Autociclo");
        dao.agregarComponente("AUTO", "AUTO", d("1"));
        verdad(dao.detectarCiclos().contains("AUTO -> AUTO"));
        falla(IllegalStateException.class, () -> dao.calcularCostoTotal("AUTO"));

        CostosProductosDAO ejemplo = new CostosProductosDAO();
        ejemplo.cargarEjemplo();
        numero("180", ejemplo.calcularCostoTotal("BASE"));
        numero("290", ejemplo.calcularCostoTotal("EQUIPO"));
        numero("260", ejemplo.calcularCostoTotal("EQUIPO2"));
        igual(List.of(), ejemplo.detectarCiclos());
        falla(IllegalStateException.class, ejemplo::cargarEjemplo);
        igual(7, ejemplo.listarProductos().size());
        falla(IllegalArgumentException.class, () -> new ComponenteModelo("C", null));
        falla(IllegalArgumentException.class, () -> new ProductoModelo("X", "x", true, d("1"), List.of()));
        falla(IllegalArgumentException.class, () -> new ProductoModelo("X", "x", false, d("1"), List.of(new ComponenteModelo("C", d("1")))));

        // La vista cubre ejemplo, cálculo, desglose, compartidos, ciclos, reporte y salida.
        String consola = ejecutarVista("12\n6\nEQUIPO\n7\nEQUIPO\n8\n9\n10\nEQUIPO\n2\n11\n0\n");
        verdad(consola.contains("Costo por unidad: 290"));
        verdad(consola.contains("Costo estimado total: 580"));
        verdad(consola.contains("Programa finalizado."));
        String manual = ejecutarVista("1\nC\nPieza\n2.50\n2\nP\nProducto\n4\nP\nC\n3\n"
                + "5\nP\nC\n4\n3\nC\n3\n6\nP\n10\nP\n2\n9\n0\n");
        verdad(manual.contains("Componente registrado."));
        verdad(manual.contains("Cantidad actualizada."));
        verdad(manual.contains("Costo por unidad: 12"));
        verdad(manual.contains("Costo estimado total: 24"));
        verdad(ejecutarVista("").contains("Fin de la entrada."));
        verdad(ejecutarVista("abc\n99\n0\n").contains("Opción no válida."));
        System.out.println("Pruebas CostosProductos: " + comprobaciones + " comprobaciones superadas.");
    }

    private static BigDecimal d(String valor) { return new BigDecimal(valor); }
    private static void verdad(boolean condicion) {
        comprobaciones++;
        if (!condicion) throw new AssertionError("Comprobación " + comprobaciones + " fallida.");
    }
    private static void igual(Object esperado, Object actual) {
        comprobaciones++;
        if (!esperado.equals(actual)) throw new AssertionError("Esperado " + esperado + "; recibido " + actual);
    }
    private static void numero(String esperado, BigDecimal actual) {
        comprobaciones++;
        if (d(esperado).compareTo(actual) != 0) throw new AssertionError("Esperado " + esperado + "; recibido " + actual);
    }
    private static void falla(Class<? extends Throwable> tipo, Runnable accion) {
        comprobaciones++;
        try { accion.run(); }
        catch (Throwable error) {
            if (tipo.isInstance(error)) return;
            throw new AssertionError("Se esperaba " + tipo.getSimpleName() + "; se obtuvo " + error, error);
        }
        throw new AssertionError("Se esperaba " + tipo.getSimpleName());
    }
    private static String ejecutarVista(String entrada) {
        PrintStream anterior = System.out;
        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        try (PrintStream captura = new PrintStream(salida, true, StandardCharsets.UTF_8)) {
            System.setOut(captura);
            new CostosProductosVista(new Scanner(entrada), new CostosProductosDAO()).iniciar();
        } finally { System.setOut(anterior); }
        return salida.toString(StandardCharsets.UTF_8);
    }
}
