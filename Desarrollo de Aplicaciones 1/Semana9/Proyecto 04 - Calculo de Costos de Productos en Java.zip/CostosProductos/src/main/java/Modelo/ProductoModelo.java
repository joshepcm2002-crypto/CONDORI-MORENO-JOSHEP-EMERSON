package Modelo;

import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;

/** Datos inmutables de un componente simple o producto compuesto. */
public final class ProductoModelo {
    private final String codigo;
    private final String descripcion;
    private final boolean compuesto;
    private final BigDecimal costoUnitario;
    private final List<ComponenteModelo> componentes;

    public ProductoModelo(String codigo, String descripcion, boolean compuesto,
                          BigDecimal costoUnitario, List<ComponenteModelo> componentes) {
        if (codigo == null || codigo.isBlank() || descripcion == null || descripcion.isBlank()) {
            throw new IllegalArgumentException("El código y la descripción son obligatorios.");
        }
        if (costoUnitario == null || costoUnitario.signum() < 0) {
            throw new IllegalArgumentException("El costo debe ser un número no negativo.");
        }
        if (componentes == null || componentes.stream().anyMatch(c -> c == null)) {
            throw new IllegalArgumentException("La lista de componentes no puede contener null.");
        }
        if (!compuesto && !componentes.isEmpty()) {
            throw new IllegalArgumentException("Un componente simple no puede contener otros elementos.");
        }
        if (compuesto && costoUnitario.signum() != 0) {
            throw new IllegalArgumentException("El costo del compuesto se obtiene de sus componentes.");
        }
        this.codigo = codigo.trim().toUpperCase(Locale.ROOT);
        this.descripcion = descripcion.trim();
        this.compuesto = compuesto;
        this.costoUnitario = costoUnitario;
        this.componentes = List.copyOf(componentes);
    }

    public String getCodigo() { return codigo; }
    public String getDescripcion() { return descripcion; }
    public boolean esCompuesto() { return compuesto; }
    public BigDecimal getCostoUnitario() { return costoUnitario; }
    public List<ComponenteModelo> getComponentes() { return componentes; }

    @Override public String toString() {
        return codigo + " | " + descripcion + " | " + (compuesto ? "PRODUCTO COMPUESTO" : "COMPONENTE SIMPLE");
    }
}
