package Modelo;

import java.math.BigDecimal;
import java.util.Locale;

/** Relación de composición: código del hijo y cantidad requerida por unidad del padre. */
public final class ComponenteModelo {
    private final String codigoComponente;
    private final BigDecimal cantidad;

    public ComponenteModelo(String codigoComponente, BigDecimal cantidad) {
        if (codigoComponente == null || codigoComponente.isBlank()) {
            throw new IllegalArgumentException("El código del componente es obligatorio.");
        }
        if (cantidad == null || cantidad.signum() < 0) {
            throw new IllegalArgumentException("La cantidad debe ser un número no negativo.");
        }
        this.codigoComponente = codigoComponente.trim().toUpperCase(Locale.ROOT);
        this.cantidad = cantidad;
    }

    public String getCodigoComponente() { return codigoComponente; }
    public BigDecimal getCantidad() { return cantidad; }
}
