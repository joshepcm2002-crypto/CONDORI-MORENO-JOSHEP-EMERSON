package Vista;

import DAO.CostosProductosDAO;
import Modelo.ProductoModelo;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;

/** La vista lee y presenta datos; los recorridos recursivos permanecen en el DAO. */
public final class CostosProductosVista {
    private final Scanner teclado;
    private final CostosProductosDAO dao;

    public CostosProductosVista() { this(new Scanner(System.in), new CostosProductosDAO()); }

    public CostosProductosVista(Scanner teclado, CostosProductosDAO dao) {
        if (teclado == null || dao == null) throw new IllegalArgumentException("La vista requiere teclado y DAO.");
        this.teclado = teclado;
        this.dao = dao;
    }

    public void iniciar() {
        System.out.println("SEMANA 09 - COSTOS DE PRODUCTOS COMPUESTOS");
        System.out.println("Datos en memoria. Los costos y cantidades se ingresan con punto decimal.");
        System.out.println("Costo del compuesto = suma de cantidad por costo de cada parte.");
        while (true) {
            try {
                menu();
                int opcion = Integer.parseInt(leer("Opción: "));
                switch (opcion) {
                    case 0 -> { System.out.println("Programa finalizado."); return; }
                    case 1 -> {
                        dao.registrarComponente(leer("Código: "), leer("Descripción: "), decimal("Costo unitario: "));
                        System.out.println("Componente registrado.");
                    }
                    case 2 -> {
                        dao.registrarProducto(leer("Código: "), leer("Descripción: "));
                        System.out.println("Producto compuesto registrado; sin partes su costo es cero.");
                    }
                    case 3 -> {
                        dao.registrarCostoUnitario(leer("Código del componente simple: "), decimal("Nuevo costo unitario: "));
                        System.out.println("Costo actualizado.");
                    }
                    case 4 -> {
                        dao.agregarComponente(leer("Código del producto padre: "), leer("Código de la parte: "),
                                decimal("Cantidad por unidad del padre: "));
                        System.out.println("Relación registrada. Use la opción 9 para revisar ciclos.");
                    }
                    case 5 -> {
                        dao.actualizarCantidad(leer("Código del producto padre: "), leer("Código de la parte: "),
                                decimal("Nueva cantidad por unidad del padre: "));
                        System.out.println("Cantidad actualizada.");
                    }
                    case 6 -> {
                        String codigo = leer("Código a calcular: ");
                        System.out.println("Costo por unidad: " + CostosProductosDAO.numero(dao.calcularCostoTotal(codigo)));
                    }
                    case 7 -> System.out.print(dao.mostrarDesglose(leer("Código del producto: ")));
                    case 8 -> mostrarCompartidos();
                    case 9 -> mostrarCiclos();
                    case 10 -> System.out.print(dao.generarReporteFabricacion(leer("Código del producto: "),
                            decimal("Unidades a fabricar: ")));
                    case 11 -> listar();
                    case 12 -> {
                        dao.cargarEjemplo();
                        System.out.println("Ejemplo cargado. BASE = 180; EQUIPO = 290; EQUIPO2 = 260.");
                    }
                    default -> System.out.println("Opción no válida.");
                }
            } catch (NoSuchElementException e) {
                System.out.println("Fin de la entrada. Programa finalizado.");
                return;
            } catch (NumberFormatException e) {
                System.out.println("Error: ingrese un número válido, con punto para los decimales.");
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void menu() {
        System.out.println("\n1. Registrar componente simple y costo unitario");
        System.out.println("2. Registrar producto compuesto");
        System.out.println("3. Registrar o actualizar costo unitario");
        System.out.println("4. Agregar relación de composición y cantidad");
        System.out.println("5. Actualizar cantidad de una relación");
        System.out.println("6. Calcular costo total recursivamente");
        System.out.println("7. Mostrar desglose por niveles");
        System.out.println("8. Identificar componentes compartidos");
        System.out.println("9. Detectar ciclos en toda la composición");
        System.out.println("10. Generar reporte de fabricación");
        System.out.println("11. Listar productos y componentes");
        System.out.println("12. Cargar ejemplo de prueba (solo en registro vacío)");
        System.out.println("0. Salir");
    }

    private void listar() {
        List<ProductoModelo> productos = dao.listarProductos();
        if (productos.isEmpty()) System.out.println("No hay registros.");
        for (ProductoModelo producto : productos) {
            System.out.println(producto + (producto.esCompuesto() ? "" :
                    " | costo unitario: " + CostosProductosDAO.numero(producto.getCostoUnitario())));
        }
    }

    private void mostrarCompartidos() {
        Map<String, List<String>> compartidos = dao.identificarComponentesCompartidos();
        System.out.println("Compartidos: parte -> productos que la contienen directa o indirectamente.");
        if (compartidos.isEmpty()) System.out.println("No hay componentes compartidos entre productos distintos.");
        compartidos.forEach((codigo, propietarios) -> System.out.println(codigo + " -> " + String.join(", ", propietarios)));
    }

    private void mostrarCiclos() {
        List<String> ciclos = dao.detectarCiclos();
        if (ciclos.isEmpty()) System.out.println("No se detectaron ciclos.");
        else {
            System.out.println("Ciclos detectados; no se puede calcular una composición que los alcance:");
            ciclos.forEach(System.out::println);
        }
    }

    private String leer(String mensaje) {
        System.out.print(mensaje);
        if (!teclado.hasNextLine()) throw new NoSuchElementException("Fin de la entrada.");
        return teclado.nextLine().trim();
    }

    private BigDecimal decimal(String mensaje) { return new BigDecimal(leer(mensaje)); }
}
