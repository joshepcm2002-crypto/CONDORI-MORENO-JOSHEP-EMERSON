package DAO;

import Modelo.ComponenteModelo;
import Modelo.ProductoModelo;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Registro en memoria y algoritmos recursivos de composición del proyecto 04. */
public final class CostosProductosDAO {
    private final Map<String, ProductoModelo> productos = new LinkedHashMap<>();

    // RF01 y RF02: los códigos son únicos, sin distinguir mayúsculas.
    public ProductoModelo registrarComponente(String codigo, String descripcion, BigDecimal costo) {
        return registrar(new ProductoModelo(codigo, descripcion, false, costo, List.of()));
    }

    public ProductoModelo registrarProducto(String codigo, String descripcion) {
        return registrar(new ProductoModelo(codigo, descripcion, true, BigDecimal.ZERO, List.of()));
    }

    private ProductoModelo registrar(ProductoModelo producto) {
        if (productos.containsKey(producto.getCodigo())) {
            throw new IllegalArgumentException("Ya existe el código " + producto.getCodigo() + ".");
        }
        productos.put(producto.getCodigo(), producto);
        return producto;
    }

    public ProductoModelo buscarProducto(String codigo) {
        ProductoModelo producto = productos.get(normalizar(codigo));
        if (producto == null) throw new IllegalArgumentException("No existe el código " + codigo + ".");
        return producto;
    }

    public List<ProductoModelo> listarProductos() { return List.copyOf(productos.values()); }

    public void registrarCostoUnitario(String codigo, BigDecimal costo) {
        ProductoModelo actual = buscarProducto(codigo);
        if (actual.esCompuesto()) {
            throw new IllegalArgumentException("El costo del compuesto se calcula a partir de sus partes.");
        }
        // Construir y validar antes de sustituir: un error conserva el registro anterior.
        ProductoModelo nuevo = new ProductoModelo(actual.getCodigo(), actual.getDescripcion(), false, costo, List.of());
        productos.put(actual.getCodigo(), nuevo);
    }

    // RF03 y RF04: una cantidad es por unidad del padre, no una cantidad global.
    public void agregarComponente(String codigoProducto, String codigoComponente, BigDecimal cantidad) {
        ProductoModelo padre = exigirCompuesto(codigoProducto);
        ProductoModelo hijo = buscarProducto(codigoComponente);
        ComponenteModelo relacion = new ComponenteModelo(hijo.getCodigo(), cantidad);
        if (padre.getComponentes().stream().anyMatch(c -> c.getCodigoComponente().equals(hijo.getCodigo()))) {
            throw new IllegalArgumentException("La relación ya existe; use actualizar cantidad.");
        }
        List<ComponenteModelo> relaciones = new ArrayList<>(padre.getComponentes());
        relaciones.add(relacion);
        sustituirRelaciones(padre, relaciones);
        // Se permiten ciclos registrados para poder detectarlos mediante RF08.
        // Los algoritmos de costo y desglose los rechazan, en lugar de entrar en recursión infinita.
    }

    public void actualizarCantidad(String codigoProducto, String codigoComponente, BigDecimal cantidad) {
        ProductoModelo padre = exigirCompuesto(codigoProducto);
        String codigo = buscarProducto(codigoComponente).getCodigo();
        ComponenteModelo reemplazo = new ComponenteModelo(codigo, cantidad);
        List<ComponenteModelo> relaciones = new ArrayList<>(padre.getComponentes());
        for (int i = 0; i < relaciones.size(); i++) {
            if (relaciones.get(i).getCodigoComponente().equals(codigo)) {
                relaciones.set(i, reemplazo);
                sustituirRelaciones(padre, relaciones);
                return;
            }
        }
        throw new IllegalArgumentException("No existe esa relación de composición.");
    }

    private ProductoModelo exigirCompuesto(String codigo) {
        ProductoModelo producto = buscarProducto(codigo);
        if (!producto.esCompuesto()) throw new IllegalArgumentException("El padre debe ser un producto compuesto.");
        return producto;
    }

    private void sustituirRelaciones(ProductoModelo padre, List<ComponenteModelo> relaciones) {
        productos.put(padre.getCodigo(), new ProductoModelo(padre.getCodigo(), padre.getDescripcion(),
                true, BigDecimal.ZERO, relaciones));
    }

    // RF05: el inicio prepara la memoria y la ruta; el auxiliar realiza la recursión.
    public BigDecimal calcularCostoTotal(String codigo) {
        ProductoModelo producto = buscarProducto(codigo);
        return calcularCosto(producto.getCodigo(), new LinkedHashSet<>(), new LinkedHashMap<>());
    }

    private BigDecimal calcularCosto(String codigo, Set<String> ruta, Map<String, BigDecimal> memoria) {
        if (ruta.contains(codigo)) {
            throw new IllegalStateException("Ciclo de composición: " + describirCiclo(ruta, codigo));
        }
        if (memoria.containsKey(codigo)) return memoria.get(codigo);
        ProductoModelo actual = buscarProducto(codigo);
        // Caso base: una hoja devuelve directamente su costo unitario.
        if (!actual.esCompuesto()) {
            memoria.put(codigo, actual.getCostoUnitario());
            return actual.getCostoUnitario();
        }
        ruta.add(codigo);
        BigDecimal total = BigDecimal.ZERO;
        for (ComponenteModelo relacion : actual.getComponentes()) {
            BigDecimal costoHijo = calcularCosto(relacion.getCodigoComponente(), ruta, memoria);
            total = total.add(relacion.getCantidad().multiply(costoHijo));
        }
        ruta.remove(codigo);
        memoria.put(codigo, total);
        // Compuesto vacío: el ciclo no se ejecuta y se retorna cero.
        return total;
    }

    // RF06: cada rama se muestra, aunque un componente también aparezca en otra rama.
    public String mostrarDesglose(String codigo) {
        ProductoModelo raiz = buscarProducto(codigo);
        Map<String, BigDecimal> costos = new LinkedHashMap<>();
        calcularCosto(raiz.getCodigo(), new LinkedHashSet<>(), costos); // Valida todo antes de emitir un reporte.
        StringBuilder salida = new StringBuilder("NIVEL | CÓDIGO | CANT. ACUMULADA | COSTO POR UNIDAD | APORTE\n");
        desglosar(raiz.getCodigo(), 0, BigDecimal.ONE, costos, salida);
        salida.append("Los subtotales de padres incluyen a sus hijos; no se suman todas las filas.\n");
        return salida.toString();
    }

    private void desglosar(String codigo, int nivel, BigDecimal cantidadAcumulada,
                           Map<String, BigDecimal> costos, StringBuilder salida) {
        ProductoModelo actual = buscarProducto(codigo);
        BigDecimal costo = costos.get(codigo);
        salida.append(nivel).append(" | ").append("  ".repeat(nivel)).append(codigo)
                .append(" | ").append(numero(cantidadAcumulada)).append(" | ").append(numero(costo))
                .append(" | ").append(numero(cantidadAcumulada.multiply(costo))).append('\n');
        for (ComponenteModelo relacion : actual.getComponentes()) {
            desglosar(relacion.getCodigoComponente(), nivel + 1,
                    cantidadAcumulada.multiply(relacion.getCantidad()), costos, salida);
        }
    }

    // RF07: un componente es compartido si aparece directa o indirectamente en dos productos distintos.
    // El conjunto por producto impide contar dos veces el mismo componente para ese propietario.
    public Map<String, List<String>> identificarComponentesCompartidos() {
        Map<String, List<String>> propietarios = new LinkedHashMap<>();
        for (ProductoModelo producto : productos.values()) {
            if (!producto.esCompuesto()) continue;
            Set<String> descendientes = new LinkedHashSet<>();
            reunirDescendientes(producto.getCodigo(), new LinkedHashSet<>(), descendientes);
            descendientes.remove(producto.getCodigo());
            for (String codigo : descendientes) {
                propietarios.computeIfAbsent(codigo, clave -> new ArrayList<>()).add(producto.getCodigo());
            }
        }
        Map<String, List<String>> resultado = new LinkedHashMap<>();
        propietarios.forEach((codigo, padres) -> {
            if (padres.size() > 1) resultado.put(codigo, List.copyOf(padres));
        });
        return Collections.unmodifiableMap(resultado);
    }

    private void reunirDescendientes(String codigo, Set<String> visitados, Set<String> resultado) {
        if (!visitados.add(codigo)) return;
        for (ComponenteModelo relacion : buscarProducto(codigo).getComponentes()) {
            resultado.add(relacion.getCodigoComponente());
            reunirDescendientes(relacion.getCodigoComponente(), visitados, resultado);
        }
    }

    // RF08: visitados evita repetir subgrafos; ruta identifica un regreso a un ancestro activo.
    public List<String> detectarCiclos() {
        Set<String> visitados = new LinkedHashSet<>();
        Set<String> ruta = new LinkedHashSet<>();
        List<String> ciclos = new ArrayList<>();
        for (String codigo : productos.keySet()) detectar(codigo, visitados, ruta, ciclos);
        return List.copyOf(ciclos);
    }

    private void detectar(String codigo, Set<String> visitados, Set<String> ruta, List<String> ciclos) {
        if (ruta.contains(codigo)) {
            ciclos.add(describirCiclo(ruta, codigo));
            return;
        }
        if (!visitados.add(codigo)) return;
        ruta.add(codigo);
        for (ComponenteModelo relacion : buscarProducto(codigo).getComponentes()) {
            detectar(relacion.getCodigoComponente(), visitados, ruta, ciclos);
        }
        ruta.remove(codigo);
    }

    private static String describirCiclo(Set<String> ruta, String repetido) {
        List<String> secuencia = new ArrayList<>(ruta);
        int inicio = secuencia.indexOf(repetido);
        List<String> ciclo = new ArrayList<>(secuencia.subList(Math.max(0, inicio), secuencia.size()));
        ciclo.add(repetido);
        return String.join(" -> ", ciclo);
    }

    // RF10: reporte por producto, sin mezclar subtotales y total final.
    public String generarReporteFabricacion(String codigo, BigDecimal unidades) {
        if (unidades == null || unidades.signum() < 0) {
            throw new IllegalArgumentException("Las unidades a fabricar deben ser un número no negativo.");
        }
        ProductoModelo producto = buscarProducto(codigo);
        BigDecimal costoUnitario = calcularCostoTotal(codigo);
        return "REPORTE DE COSTO ESTIMADO DE FABRICACIÓN\n"
                + "Producto: " + producto.getCodigo() + " | " + producto.getDescripcion() + "\n"
                + "Unidades a fabricar: " + numero(unidades) + "\n"
                + "Costo por unidad: " + numero(costoUnitario) + "\n"
                + "Costo estimado total: " + numero(costoUnitario.multiply(unidades)) + "\n"
                + "Desglose de composición para UNA unidad del producto:\n"
                + mostrarDesglose(codigo);
    }

    public void cargarEjemplo() {
        if (!productos.isEmpty()) throw new IllegalStateException("El ejemplo solo se carga en un registro vacío.");
        registrarComponente("PLACA", "Placa electrónica", new BigDecimal("100"));
        registrarComponente("RAM", "Módulo de memoria", new BigDecimal("40"));
        registrarComponente("SSD", "Unidad de almacenamiento", new BigDecimal("60"));
        registrarComponente("FUENTE", "Fuente de alimentación", new BigDecimal("50"));
        registrarProducto("BASE", "Subconjunto base");
        agregarComponente("BASE", "PLACA", BigDecimal.ONE);
        agregarComponente("BASE", "RAM", new BigDecimal("2"));
        registrarProducto("EQUIPO", "Equipo informático");
        agregarComponente("EQUIPO", "BASE", BigDecimal.ONE);
        agregarComponente("EQUIPO", "SSD", BigDecimal.ONE);
        agregarComponente("EQUIPO", "FUENTE", BigDecimal.ONE);
        registrarProducto("EQUIPO2", "Equipo de doble memoria");
        agregarComponente("EQUIPO2", "BASE", BigDecimal.ONE);
        agregarComponente("EQUIPO2", "RAM", new BigDecimal("2"));
    }

    private static String normalizar(String codigo) {
        if (codigo == null || codigo.isBlank()) throw new IllegalArgumentException("El código es obligatorio.");
        return codigo.trim().toUpperCase(Locale.ROOT);
    }

    public static String numero(BigDecimal valor) { return valor.stripTrailingZeros().toPlainString(); }
}
